#define F_CPU 1000000UL
 
#include <avr/io.h>              

#define RED 0
#define BLUE 1
#define GREEN 2

//for a delay of 1 second, n = about 23000
void delay(long n)
{
        long a;
        for(a=0;a<n;a++)
        {
                //do nothing, fast!
        }
}

// ***********************************************************
// Main program
//

int led=GREEN;

int main(void)
{
    //initialization of ports
    DDRD = 0x00;
    DDRB = 0xFF;
    PORTB = 0xFF;
    PORTD = 0xFF;
 
   while(1) //infinite looooooooooooooooooooooooooop
   {
     while ((~PIND & 1))
       switch (led) {
         case RED:
	   PORTB=0xFE;
	   delay(5000);
           led=BLUE;
	   break;
         case BLUE:
	   PORTB=0xFD;
	   delay(5000);
           led=GREEN;
           break;
         case GREEN:
           PORTB=0xFB;
           delay(5000);
           led=RED;
           break;
       }
   }
   return 1;
}

