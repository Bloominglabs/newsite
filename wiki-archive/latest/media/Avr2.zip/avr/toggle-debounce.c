
#define F_CPU 1000000UL
 
#include <avr/io.h>              
#include <avr/interrupt.h>    
 
char state;

//for a delay of 1 second, n = about 23000
void delay(long n)
{
        long a;
        for(a=0;a<n;a++)
        {
                //do nothing, fast!
        }
}

// ***********************************************************
// Main program
//

int ledoff;

int main(void)
{
    //initialization of ports
    DDRD = 0x00;
    DDRB = 0xFF;
    PORTB = 0x00;
    PORTD = 0xFF;
 
   while(1) //infinite looooooooooooooooooooooooooop
   {
     while ((~PIND & 1))
       {
	 if (ledoff) {        
	   PORTB=0xFF;
	   delay(5000);
           ledoff=0;
	 }
	 else {
	   PORTB=0x00;
	   delay(5000);
           ledoff=1;
	 }
       }
   }
    return 1;
}

