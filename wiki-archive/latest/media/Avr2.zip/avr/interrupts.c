
#define F_CPU 1000000UL
 
#include <avr/io.h>              
#include <avr/interrupt.h>    
 
int ledoff=0;

//for a delay of 1 second, n = about 23000
void delay(long n)
{
        long a;
        for(a=0;a<n;a++)
        {
                //do nothing, fast!
        }
}

ISR(INT0_vect)
{
   GICR &= ~(1 << INT0);

   delay(2300);

   if (ledoff) {
      PORTB = 0x00;
      ledoff=0;
   }
   else {
      PORTB = 0xFF;
      ledoff=1;
   }
}
 
// ***********************************************************
// Main program
//
int main(void)
{
    //initialization of ports and interrupts
    //p. 58 SFIOR details
    SFIOR &= ~(1 << PUD); //ensure pull-up-disable is disabled
    DDRD = (0 << PD2); //PD2 as input
    DDRB = 0xFF;
    PORTB = 0x00;
    PORTD = 0xFF; //set internal pull-ups on
 
    //interrupts covered on p.66 of atmega8 datasheet
    MCUCR |= (1 << ISC01) | (1 << ISC00); // rising edge trigger
    GICR |= (1 << INT0);                         // enable INT0
 
    sei(); //enable interrupts
   
   while(1) //infinite looooooooooooooooooooooooooop
   {
     // If INT0 is off, then turn it back on after waiting a bit
     if((GICR & (1 << INT0)) == 0) {
       // Clear any waiting interrupts and enable
       GIFR |= (1 << INTF0); // Clear
       GICR |= (1 << INT0); // Enable
     }
   }
    return 1;
}

