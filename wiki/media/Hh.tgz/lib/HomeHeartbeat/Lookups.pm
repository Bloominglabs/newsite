package HomeHeartbeat::Lookups;
#use strict;
#use warnings;

use Exporter qw(import);
our @EXPORT_OK = qw(useTelnet useSerial printHtmlHeader decodeTimer devTypeLookup devConfigLookup devNameIndexLookup checkAlert alertNotify);

#####################################################################################################################
# 2013-11-18 / dosman / Home Heartbeat script - It digests the state table of the Home Heartbeat base station
# v1.0                  and outputs human readable data. I have not tested the email functionality yet, but the 
#                       other functions work fine. For updates and other info about this script check out this page:
#                       http://bloominglabs.org/index.php/Eaton_Home_Heartbeat
#
#####################################################################################################################
# The Vendor ID for the FTDI chip in the base station is unique to Eaton, but otherwise this is a genric FTDI USB->Serial interface.
# Add a modprobe line for ftdi_sio driver, get vendor and product lines from lsusb:
# echo "options ftdi_sio vendor=0x403 product=0xde29" > /etc/modprobe.d/ftdi_sio.conf
#
# Reload ftdi_sio (or reboot) and it should be picked up correctly now:
# modprobe -r ftdi_sio
# modprobe ftdi_sio
#
#####################################################################################################################
# All field information obtained from this site and my own hardware:
# http://www.kolinahr.com/documentation/home-heartbeat/state-table-of-the-eaton-home-heartbeat/
#
# Output field format:
# STATE="F1,F2,F3,F4,F5,F6,F7,F8,F9,F10,F11,F12,F13,F14,F15,F16,F17"
# STATE="02,00,0040,0002,00,12,00,00,0301,12,0000,00,FF,00000000,00,000D6F0000011367,Home Key"


# Field 1 State Record ID 0 This is a number associated with each device as it's associated with the base station, however it can be changed so do not rely on 
# this. Using "Forget Device" on the home key will cause the devices to renumber.

# Field 2 ZigBee Binding ID 0 This value is an index into the ZigBee Binding Table.

# Field 3 Device Capabilities - field is constant for each device, this field is still not fully understood
$CAPABILITY_UNKNOWN1="01";
$CAPABILITY_UNKNOWN2="02";
$CAPABILITY_SENSOR1="04";
$CAPABILITY_BASESTATION="08";
$CAPABILITY_RECEIVESPARAMS="10"; # Motion, Power, and Reminder sensors
$CAPABILITY_SENSOR2="20";
$CAPABILITY_HOMEKEY="40";
$CAPABILITY_AC="80"; # Base station, modem, and power sensors

# Field 4 Device Type
$TYPE_BASE="0001";
$TYPE_HOMEKEY="0002";
$TYPE_OPENCLOSE="0003";
$TYPE_POWER="0004";
$TYPE_WATER="0005";
$TYPE_REMINDER="0006";
$TYPE_ATTENTION="0007";
$TYPE_MODEM="0010";
$TYPE_MOTION="0017";
$TYPE_TILT="0018";
$TYPE_BBGATE="0012";
# We don't know what values the range extender and water cutoff controller use yet!
$TYPE_RANGEX="null";
$TYPE_WATERSHUTOFF="null";

# Field 5 Device State - This field contains the last reported state of the device.
# Field 6 Device State Timer - This is the elapsed time since the device state has changed.

# Field 7 Device Alerts
$ALARM_TRIGGERED="01";
$DEV_OFFLINE="02"; # device offline, out of range, or battery dead
$BATTERY_LOW="04";
$BATTERY_CHARGING="08"; # only used by home key
$RUNNING_ON_BATTERY="20"; # only used by base station

# Field 8 Device Name Index - This is an index into a predefined list of available names specific to the device type, also Field 17 contains the complete name retrieved out of the index.

# Field 9 Device Configuration
$ALARM1="0001";
$ALARM2="0002";
$CALLME1="0100";
$CALLME2="0200";

# Field 10 Alive Update Timer - This is the elapsed time since that last “I’m Alive” message received from the device.
# Field 11 Update Flags - This field is normally zero (0x00) for all devices. It has been observed to contain the value 0x80 when there is pending data needing to be sent to the device. Please read the description under Field 13: Device Parameter section below.
# Field 12 Undefined
# Field 13 Device Parameter - This field may contain a user selectable configuration value. Only a few devices have the ability to accept a configuration parameter. Power, Reminder, and Motion.
# Field 14 Undefined
# Field 15 Pending Update Timer - This is the elapsed time since the user changed the device configuration parameter defined in Field 13
# Field 16 MAC Address
# Field 17 Device Name

#####################################################################################################################

sub useTelnet
{
my $host = "localhost";
my $port = "6001";

use Net::Telnet;
  $telnet = new Net::Telnet (Timeout=>10, Port=>$port,
  Errmode=>'die');

  $telnet->open("$host");

  # Request the state table
  $telnet->print('S');

  while (1)
  {
    my $input = $telnet->getline();
    $input =~ s/\r//g;
    if ($input ne ""){
        if ($input =~ /STATE=NEW/){
            next;
        } else {
            push(@stateTable, "$input");
        }
    }
    if ($input =~ /STATE=DONE/){
      pop(@stateTable);
      last;
    }
    $input = "";
  }
  
  #$output4 = $telnet->getline();
}

# Most people will probably want to use this instead for direct USB-serial connectivity
#$DEV="/dev/ttyUSB0";
#@stateTableMain=();
sub useSerial
{
 $DEV="/dev/ttyUSB0";
  @stateTable=();
  use Device::SerialPort;
  $port = Device::SerialPort->new("$DEV");
  $port->databits(8);
  $port->baudrate(38400); # All Home-Heartbeat base stations should use this baud rate
  $port->parity("none");
  $port->stopbits(1);
  
  # Request the state table
  $port->write("S\n");

  while (1)
  {
    my $input = $port->lookfor();
    $input =~ s/\r//g;
    if ($input ne ""){
        # This is where we exclude any weirdness from the serial output - and there appears to be a fair bit of it
        if ($input =~ m/^STATE="/){
            push(@stateTable, "$input");
        }
    }
    if ($input =~ /STATE=DONE/){
      # Dump the STATE=DONE line / no longer needed since we match STATE=" above...
      #pop(@stateTable);
      last;
    }
    $input = "";
  }

} 

#####################################################################################################################
# Begin subroutines

sub printHtmlHeader
{
  #  open(my $output, ">", "/opt/www/house/automation/sensors.html") 
  #       or die "cannot open > sensors.html: $!";
  open HTMLOUT, ">$htmlOut" or die $!;
  print HTMLOUT "<html><title>DOSNET Sensor Network</title><body><meta http-equiv=\"refresh\" content=\"60\"><h1>DOSNET Sensor Network</h1><font size=$fontSize>";
  
  use POSIX qw(tzset);
  $ENV{TZ} = 'America/New_York';tzset;
  my $date = localtime;
  print HTMLOUT "$date";
  print HTMLOUT "<table border=2><tr> <th><font size=$fontSize>Sensor</th> <th><font size=$fontSize>Last seen</th> <th><font size=$fontSize>Last event</th> <th><font size=$fontSize>Alert</th> </tr>\n";
}

sub decodeTimer
{
    my $devStateTimer = hex("@_");
    if($devStateTimer < 64 ){
       return " $devStateTimer secs";
    }
    elsif ($devStateTimer < 128){
       my $var = $devStateTimer - 64;
       return " $var mins";
    } elsif ($devStateTimer < 160){
       my $var = $devStateTimer - 128;
       return " $var hours";
    } else {
       my $var = $devStateTimer - 160;
       return " $var days";
    }
    # There could be an additional date specification for periods beyond days, we just don't know...
}

sub devTypeLookup
{
  my $devType = $_[0];
  if($devType == $TYPE_BASE){ return "Base Station"; }
  elsif ($devType == $TYPE_HOMEKEY){ return "Home Key"; }
  elsif ($devType == $TYPE_OPENCLOSE){ return "Open/Closed"; }
  elsif ($devType == $TYPE_POWER){ return "Power Sensor"; }
  elsif ($devType == $TYPE_WATER){ return "Water Sensor"; }
  elsif ($devType == $TYPE_REMINDER){ return "Reminder Sensor"; }
  elsif ($devType == $TYPE_ATTENTION){ return "Attention Sensor"; }
  elsif ($devType == $TYPE_MODEM){ return "Modem"; }
  elsif ($devType == $TYPE_MOTION){ return "Motion Sensor"; }
  elsif ($devType == $TYPE_TILT){ return "Tilt Sensor"; }
  elsif ($devType == $TYPE_BBGATE){ return "Broadband Gateway Extender"; }
  else {
      print ERRORLOG "$date - devTypeLookup() had unknown devType \"$devType\"\n";
      return "Unknown $devType";
  }
}

sub devConfigLookup
{
  my $devType = $_[0];
  my $devConfig = $_[1];

  if($devType == $TYPE_MOTION){
      if($devConfig == "0000"){ return "No action set"; }
      elsif($devConfig == "0001"){ return "Alarm on no motion"; }
      elsif($devConfig == "0002"){ return "Alarm on motion"; }
      elsif($devConfig == "0100"){ return "Call on no motion"; }
      elsif($devConfig == "0200"){ return "Call on motion"; }
      else {
          print ERRORLOG "$date - devConfigLookup() with devType \"$devType\" had unknown devConfig value \"$devConfig\"\n";
          return "Unknown value $devConfig";
      }

  } elsif($devType == $TYPE_OPENCLOSE){
      if($devConfig == "0000"){ return "No action set"; }
      elsif($devConfig == "0001"){ return "Alarm on closed"; }
      elsif($devConfig == "0002"){ return "Alarm on opened"; }
      elsif($devConfig == "0100"){ return "Call on closed"; }
      elsif($devConfig == "0200"){ return "Call on opened"; }
      else {
          print ERRORLOG "$date - devConfigLookup() with devType \"$devType\" had unknown devConfig value \"$devConfig\"\n";
          return "Unknown value $devConfig";
      }

  } elsif($devType == $TYPE_WATER){
      if($devConfig == "0000"){ return "No action set"; }
      elsif($devConfig == "0001"){ return "Alarm on wet"; }
      elsif($devConfig == "0002"){ return "Alarm on dry"; }
      elsif($devConfig == "0100"){ return "Call on wet"; }
      elsif($devConfig == "0200"){ return "Call on dry"; }
      else {
          print ERRORLOG "$date - devConfigLookup() with devType \"$devType\" had unknown devConfig value \"$devConfig\"\n";
          return "Unknown value $devConfig";
      }

  } elsif($devType == $TYPE_ATTENTION){
      if($devConfig == "0000"){ return "No action set"; }
      elsif($devConfig == "0001"){ return "Alarm on requested"; }
      elsif($devConfig == "0002"){ return "Alarm on standby"; }
      elsif($devConfig == "0100"){ return "Call on requested"; }
      elsif($devConfig == "0200"){ return "Call on standby"; }
      else {
          print ERRORLOG "$date - devConfigLookup() with devType \"$devType\" had unknown devConfig value \"$devConfig\"\n";
          return "Unknown value $devConfig";
      }

  } elsif($devType == $TYPE_REMINDER){
      if($devConfig == "0000"){ return "No action set"; }
      elsif($devConfig == "0001"){ return "Alarm on started"; }
      elsif($devConfig == "0002"){ return "Alarm on time's up"; }
      elsif($devConfig == "0100"){ return "Call on started"; }
      elsif($devConfig == "0200"){ return "Call on time's up"; }
      else {
          print ERRORLOG "$date - devConfigLookup() with devType \"$devType\" had unknown devConfig value \"$devConfig\"\n";
          return "Unknown value $devConfig";
      }

  } elsif($devType == $TYPE_POWER){
      if($devConfig == "0000"){ return "No action set"; }
      elsif($devConfig == "0001"){ return "Alarm on Off"; }
      elsif($devConfig == "0002"){ return "Alarm on On"; }
      elsif($devConfig == "0100"){ return "Call on Off"; }
      elsif($devConfig == "0200"){ return "Call on On"; }
      else {
          print ERRORLOG "$date - devConfigLookup() with devType \"$devType\" had unknown devConfig value \"$devConfig\"\n";
          return "Unknown value $devConfig";
      }

  } elsif($devType == $TYPE_TILT){
      if($devConfig == "0000"){ return "No action set"; } 
      elsif($devConfig == "0001"){ return "Alarm on closed"; }
      elsif($devConfig == "0002"){ return "Alarm on open"; }
      elsif($devConfig == "0100"){ return "Call on closed"; }
      elsif($devConfig == "0200"){ return "Call on open"; } 
      else {
          print ERRORLOG "$date - devConfigLookup() with devType \"$devType\" had unknown devConfig value \"$devConfig\"\n";
          return "Unknown value $devConfig";
      }

  } elsif($devType == $TYPE_HOMEKEY){
      my $decode;
      my $top=substr($devConfig, 0, 2);
      my $bot=substr($devConfig, 2, 2);
      #print "top $top / bot $bot\n";
      if($bot == "00"){
          $decode="Silent Alarm";
      } elsif($bot == "01"){
          $decode="Beep Alarm";
      } elsif($bot == "02"){
          $decode="Vibrate Alarm";
      } else {
          print ERRORLOG "$date - devConfigLookup() with devType \"$devType\" had unknown bot value \"$bot\"\n";
          $decode="Unknown value $bot";
      }

      if($top == "00"){
          $decode="$decode / 10 sec battery update";
      } elsif($top == "01"){
          $decode="$decode / 30 sec battery update";
      } elsif($top == "02"){
          $decode="$decode / 1 min battery update";
      } elsif($top == "03"){
          $decode="$decode / 2 min battery update";
      } elsif($top == "04"){
          $decode="$decode / 15 min battery update";
      } elsif($top == "05"){
          $decode="$decode / 1 hour battery update";
      } else {
          print ERRORLOG "$date - devConfigLookup() with devType \"$devType\" had unknown tot value \"$top\"\n";
          $decode="$decode Unknown value $top";
      }
      return $decode;

  } elsif($devType == $TYPE_BASE){
      my $decode;
      my $top=substr($devConfig, 0, 2);
      my $bot=substr($devConfig, 2, 2);
      if($bot == "00"){
          $decode="Global don't call me";
      } elsif($bot == "01"){
          $decode="Global call me always";
      } elsif($bot == "02"){
          $decode="Global automatic call me";
      } else {
          print ERRORLOG "$date - devConfigLookup() with devType \"$devType\" had unknown bot value \"$bot\"\n";
          $decode="Unknown value $bot";
      }

      if($top == "00"){
          $decode="$decode / Do not send system info";
      } elsif($top == "01"){
          $decode="$decode / Send system info once a day";
      } elsif($top == "02"){
          $decode="$decode / Send system info twice a day";
      } elsif($top == "03"){
          $decode="$decode / Send system info four times a day";
      } else {
          print ERRORLOG "$date - devConfigLookup() with devType \"$devType\" had unknown top value \"$top\"\n";
          $decode="$decode / Unknown value $top";
      }
      return $decode;

  } elsif($devType == $TYPE_MODEM){
    return "N/A";

  } elsif($devType == $TYPE_BBGATE){
      #if($devConfig == "0000"){ return "N/A"; } 
      if($devConfig == "0201"){ return "N/A"; } 
      else {
          print ERRORLOG "$date - devConfigLookup() with devType \"$devType\" had unknown devConfig value \"$devConfig\"\n";
          return "Unknown value $devConfig";
      }

  } else {  # Catch-all for unknown devices
          print ERRORLOG "$date - Unknown devType \"$devType\" had unknown devConfig value \"$devConfig\"\n";
          return "Unknown devType \"$devType\" and value $devConfig";
      
  }
}

# If you are hacking/adding new device names customize the name here:
sub devNameIndexLookup
{
  my $devType = $_[0];
  my $devNameIndex = $_[1];
  $devNameIndex = hex("$devNameIndex");
  if($devType == "$TYPE_OPENCLOSE"){
    if ($devNameIndex == "00") { return "Open/Closed"; }
    elsif ($devNameIndex == "01") { return "Door"; }
    elsif ($devNameIndex == "02") { return "Window"; }
    elsif ($devNameIndex == "03") { return "Back Door"; }
    elsif ($devNameIndex == "04") { return "Basement Door"; }
    elsif ($devNameIndex == "05") { return "Bathroom Door"; }
    elsif ($devNameIndex == "06") { return "Bedroom Door"; }
    elsif ($devNameIndex == "07") { return "Deck Door"; }
    elsif ($devNameIndex == "08") { return "Dining Room Door"; }
    elsif ($devNameIndex == "09") { return "Front Door"; }
    elsif ($devNameIndex == "10") { return "Garage Door"; }
    elsif ($devNameIndex == "11") { return "Kitchen Door"; }
    elsif ($devNameIndex == "12") { return "Pet Door"; }
    elsif ($devNameIndex == "13") { return "Side Door"; }
    elsif ($devNameIndex == "14") { return "Back Window"; }
    elsif ($devNameIndex == "15") { return "Basement Window"; }
    elsif ($devNameIndex == "16") { return "Bathroom Window"; }
    elsif ($devNameIndex == "17") { return "Bedroom Window"; }
    elsif ($devNameIndex == "18") { return "Dining Room Window"; }
    elsif ($devNameIndex == "19") { return "Front Window"; }
    elsif ($devNameIndex == "20") { return "Kitchen Window"; }
    elsif ($devNameIndex == "21") { return "Living Room Window"; }
    elsif ($devNameIndex == "22") { return "Side Window"; }
    elsif ($devNameIndex == "23") { return "Closet"; }
    elsif ($devNameIndex == "24") { return "Cabinet"; }
    elsif ($devNameIndex == "25") { return "Kitchen Cabinet"; }
    elsif ($devNameIndex == "26") { return "Drawer"; }
    elsif ($devNameIndex == "27") { return "Utensil Drawer"; }
    elsif ($devNameIndex == "28") { return "Freezer"; }
    elsif ($devNameIndex == "29") { return "Gun Cabinet"; }
    elsif ($devNameIndex == "30") { return "Jewelry Box"; }
    elsif ($devNameIndex == "31") { return "Mail Box"; }
    elsif ($devNameIndex == "32") { return "Pantry"; }
    elsif ($devNameIndex == "33") { return "Refrigerator"; }
    elsif ($devNameIndex == "34") { return "Safe"; }
    elsif ($devNameIndex == "35") { return "Storage Area"; }
    elsif ($devNameIndex == "36") { return "Supply Room"; }
    elsif ($devNameIndex == "37") { return "Trunk"; }
    elsif ($devNameIndex == "38") { return "TV/Stereo Cabinet"; }
    else { 
      print ERRORLOG "$date - devNameIndexLookup() had unknown value \"$devNameIndex\" for devType \"$devType\"\n";
      return "Unknown";
    }
  } elsif($devType == "$TYPE_MOTION"){
    if ($devNameIndex == "00") { return "Motion Sensor"; }
    elsif ($devNameIndex == "01") { return "Attic"; }
    elsif ($devNameIndex == "02") { return "Back Door"; }
    elsif ($devNameIndex == "03") { return "Basement"; }
    elsif ($devNameIndex == "04") { return "Bathroom"; }
    elsif ($devNameIndex == "05") { return "Bedroom"; }
    elsif ($devNameIndex == "06") { return "Child's Room"; }
    elsif ($devNameIndex == "07") { return "Dining Room"; }
    elsif ($devNameIndex == "08") { return "Entryway"; }
    elsif ($devNameIndex == "09") { return "Front Door"; }
    elsif ($devNameIndex == "10") { return "Game Room"; }
    elsif ($devNameIndex == "11") { return "Garage"; }
    elsif ($devNameIndex == "12") { return "Garage Door"; }
    elsif ($devNameIndex == "13") { return "Kitchen"; }
    elsif ($devNameIndex == "14") { return "Hallway"; }
    elsif ($devNameIndex == "15") { return "Laundry Room"; }
    elsif ($devNameIndex == "16") { return "Pet Door"; }
    elsif ($devNameIndex == "17") { return "Sliding Door"; }
    elsif ($devNameIndex == "18") { return "Back Porch"; }
    elsif ($devNameIndex == "19") { return "Back Yard"; }
    elsif ($devNameIndex == "20") { return "Driveway"; }
    elsif ($devNameIndex == "21") { return "Detached Garage"; }
    elsif ($devNameIndex == "22") { return "Front Porch"; }
    elsif ($devNameIndex == "23") { return "Front Yard"; }
    elsif ($devNameIndex == "24") { return "Shed"; }
    elsif ($devNameIndex == "25") { return "Tool Shed"; }
    elsif ($devNameIndex == "26") { return "Mon's Home"; }
    elsif ($devNameIndex == "27") { return "Dad's Home"; }
    elsif ($devNameIndex == "28") { return "Grandma's Home"; }
    elsif ($devNameIndex == "29") { return "Grandpa's Home"; }
    elsif ($devNameIndex == "30") { return "Vacation Home"; }
    else { 
      print ERRORLOG "$date - devNameIndexLookup() had unknown value \"$devNameIndex\" for devType \"$devType\"\n";
      return "Unknown";
    }
  } elsif($devType == "$TYPE_WATER"){
    if ($devNameIndex == "00") { return "Water Sensor"; }
    elsif ($devNameIndex == "01") { return "Basement Floor"; }
    elsif ($devNameIndex == "02") { return "Bathroom Floor"; }
    elsif ($devNameIndex == "03") { return "Shower"; }
    elsif ($devNameIndex == "04") { return "Sump Pump"; }
    elsif ($devNameIndex == "05") { return "Toilet"; }
    elsif ($devNameIndex == "06") { return "Washing Machine"; }
    elsif ($devNameIndex == "07") { return "Water Heater"; }
    elsif ($devNameIndex == "08") { return "Attic"; }
    elsif ($devNameIndex == "09") { return "Bedroom"; }
    elsif ($devNameIndex == "10") { return "Crawl Space"; }
    elsif ($devNameIndex == "11") { return "Dining Room"; }
    elsif ($devNameIndex == "12") { return "Garage"; }
    elsif ($devNameIndex == "13") { return "Laundry Room"; }
    elsif ($devNameIndex == "14") { return "Living Room"; }
    elsif ($devNameIndex == "15") { return "Loft"; }
    elsif ($devNameIndex == "16") { return "Mud Room"; }
    elsif ($devNameIndex == "17") { return "Storage Area"; }
    elsif ($devNameIndex == "18") { return "Bathroom Sink"; }
    elsif ($devNameIndex == "19") { return "Bathroom Sink"; }
    elsif ($devNameIndex == "20") { return "Under Sink"; }
    elsif ($devNameIndex == "21") { return "Utility Sink"; }
    elsif ($devNameIndex == "22") { return "Cat Bowl"; }
    elsif ($devNameIndex == "23") { return "Dog Bowl"; }
    elsif ($devNameIndex == "24") { return "Fish Tank"; }
    elsif ($devNameIndex == "25") { return "Fountain"; }
    elsif ($devNameIndex == "26") { return "Garden"; }
    elsif ($devNameIndex == "27") { return "Pool"; }
    elsif ($devNameIndex == "28") { return "Water Bowl"; }
    else { 
      print ERRORLOG "$date - devNameIndexLookup() had unknown value \"$devNameIndex\" for devType \"$devType\"\n";
      return "Unknown";
    }
  } elsif($devType == "$TYPE_ATTENTION"){
    if ($devNameIndex == "00") { return "Attention Sensor"; }
    elsif ($devNameIndex == "01") { return "Be There Soon"; }
    elsif ($devNameIndex == "02") { return "Call Home"; }
    elsif ($devNameIndex == "03") { return "Call Me"; }
    elsif ($devNameIndex == "04") { return "Doorbell"; }
    elsif ($devNameIndex == "05") { return "Get Milk"; }
    elsif ($devNameIndex == "06") { return "I Love You"; }
    elsif ($devNameIndex == "07") { return "I Miss You"; }
    elsif ($devNameIndex == "08") { return "I'm Home"; }
    elsif ($devNameIndex == "09") { return "I'l Leaving"; }
    elsif ($devNameIndex == "10") { return "Need Help"; }
    elsif ($devNameIndex == "11") { return "Neighborhood Watch"; }
    elsif ($devNameIndex == "12") { return "Pick Up Dinner"; }
    elsif ($devNameIndex == "13") { return "Problem at Home"; }
    elsif ($devNameIndex == "14") { return "Thinking of You"; }
    elsif ($devNameIndex == "15") { return "Where Are You?"; }
    elsif ($devNameIndex == "16") { return "Will Call Later"; }
    elsif ($devNameIndex == "17") { return "Alert"; }
    elsif ($devNameIndex == "18") { return "Button"; }
    elsif ($devNameIndex == "19") { return "Request Button"; }
    elsif ($devNameIndex == "20") { return "Black Button"; }
    elsif ($devNameIndex == "21") { return "Blue Button"; }
    elsif ($devNameIndex == "22") { return "Green Button"; }
    elsif ($devNameIndex == "23") { return "Orange Button"; }
    elsif ($devNameIndex == "24") { return "Red Button"; }
    elsif ($devNameIndex == "25") { return "White Button"; }
    elsif ($devNameIndex == "26") { return "Yellow Button"; }
    else { 
      print ERRORLOG "$date - devNameIndexLookup() had unknown value \"$devNameIndex\" for devType \"$devType\"\n";
      return "Unknown";
    }
  } elsif($devType == "$TYPE_REMINDER"){
    if ($devNameIndex == "00") { return "Reminder Sensor"; }
    elsif ($devNameIndex == "01") { return "Call Parents"; }
    elsif ($devNameIndex == "02") { return "Change Air Filter"; }
    elsif ($devNameIndex == "03") { return "Change Batteries"; }
    elsif ($devNameIndex == "04") { return "Change Water Filter"; }
    elsif ($devNameIndex == "05") { return "Clean Cutters"; } # Cutters? Could this be Gutters?
    elsif ($devNameIndex == "06") { return "Cut Grass"; }
    elsif ($devNameIndex == "07") { return "Empty Dehumidifier"; }
    elsif ($devNameIndex == "08") { return "Feed Pet"; }
    elsif ($devNameIndex == "09") { return "Fertilize Lawn"; }
    elsif ($devNameIndex == "10") { return "Get Mail"; }
    elsif ($devNameIndex == "11") { return "Get Oil Changed"; }
    elsif ($devNameIndex == "12") { return "Our Anniversary"; }
    elsif ($devNameIndex == "13") { return "Pay Bills"; }
    elsif ($devNameIndex == "14") { return "Schedule Checkup"; }
    elsif ($devNameIndex == "15") { return "Take Medicine"; }
    elsif ($devNameIndex == "16") { return "Take Out Garbage"; }
    elsif ($devNameIndex == "17") { return "Take Out Recycle"; }
    elsif ($devNameIndex == "18") { return "Take Vitamins"; }
    elsif ($devNameIndex == "19") { return "Timer"; }
    elsif ($devNameIndex == "20") { return "Visit Dad"; }
    elsif ($devNameIndex == "21") { return "Visit Kids"; }
    elsif ($devNameIndex == "22") { return "Visit Mom"; }
    elsif ($devNameIndex == "23") { return "Walk Dog"; }
    elsif ($devNameIndex == "24") { return "Water Garden"; }
    elsif ($devNameIndex == "25") { return "Water Grass"; }
    elsif ($devNameIndex == "26") { return "Water Plants"; }
    else { 
      print ERRORLOG "$date - devNameIndexLookup() had unknown value \"$devNameIndex\" for devType \"$devType\"\n";
      return "Unknown";
    }
  } elsif($devType == "$TYPE_POWER"){
    if ($devNameIndex == "00") { return "Power Sensor"; }
    elsif ($devNameIndex == "01") { return "Appliance"; }
    elsif ($devNameIndex == "02") { return "Alarm Clock"; }
    elsif ($devNameIndex == "03") { return "Child Monitor"; }
    elsif ($devNameIndex == "04") { return "Coffee Maker"; }
    elsif ($devNameIndex == "05") { return "Computer"; }
    elsif ($devNameIndex == "06") { return "Curling Iron"; }
    elsif ($devNameIndex == "07") { return "Dehumidifier"; }
    elsif ($devNameIndex == "08") { return "Fax Machine"; }
    elsif ($devNameIndex == "09") { return "Floor Lamp"; }
    elsif ($devNameIndex == "10") { return "Gaming System"; }
    elsif ($devNameIndex == "11") { return "Iron"; }
    elsif ($devNameIndex == "12") { return "Lamp"; }
    elsif ($devNameIndex == "13") { return "Light"; }
    elsif ($devNameIndex == "14") { return "Microwave"; }
    elsif ($devNameIndex == "15") { return "Motor"; }
    elsif ($devNameIndex == "16") { return "Outdoor Light"; }
    elsif ($devNameIndex == "17") { return "Power Tool"; }
    elsif ($devNameIndex == "18") { return "Printer"; }
    elsif ($devNameIndex == "19") { return "Stereo"; }
    elsif ($devNameIndex == "20") { return "Sump Pump"; }
    elsif ($devNameIndex == "21") { return "Toaster Oven"; }
    elsif ($devNameIndex == "22") { return "TV"; }
    elsif ($devNameIndex == "23") { return "This Thing"; }
    elsif ($devNameIndex == "24") { return "That Thing"; }
    elsif ($devNameIndex == "25") { return "Those Things"; }
    elsif ($devNameIndex == "26") { return "VCR"; }
    else { 
      print ERRORLOG "$date - devNameIndexLookup() had unknown value \"$devNameIndex\" for devType \"$devType\"\n";
      return "Unknown";
    }
  } elsif($devType == "$TYPE_TILT"){
    if ($devNameIndex == "00") { return "Garage Door Sensor"; }
    elsif ($devNameIndex == "01") { return "Garage Left"; }
    elsif ($devNameIndex == "02") { return "Garage Right"; }
    elsif ($devNameIndex == "03") { return "Attic Hatch"; }
    elsif ($devNameIndex == "04") { return "Beverage Cooler"; }
    elsif ($devNameIndex == "05") { return "Box"; }
    elsif ($devNameIndex == "06") { return "Chest"; }
    elsif ($devNameIndex == "07") { return "Container"; }
    elsif ($devNameIndex == "08") { return "Hatch"; }
    elsif ($devNameIndex == "09") { return "Hope/Cedar Chest"; }
    elsif ($devNameIndex == "10") { return "Jewelry Box"; }
    elsif ($devNameIndex == "11") { return "Oven Door"; }
    elsif ($devNameIndex == "12") { return "Pet Door"; }
    elsif ($devNameIndex == "13") { return "Roll Top Desk"; }
    elsif ($devNameIndex == "14") { return "Service Hatch"; }
    elsif ($devNameIndex == "15") { return "Strongbox"; }
    elsif ($devNameIndex == "16") { return "Toy Chest"; }
    elsif ($devNameIndex == "17") { return "Tool Box"; }
    elsif ($devNameIndex == "18") { return "Tilt Sensor"; }
    elsif ($devNameIndex == "19") { return "Tilt Window"; }
    elsif ($devNameIndex == "20") { return "Trunk"; }
    elsif ($devNameIndex == "21") { return "Laptop PC"; }
    else { 
      print ERRORLOG "$date - devNameIndexLookup() had unknown value \"$devNameIndex\" for devType \"$devType\"\n";
      return "Unknown";
    }
  } elsif($devType == "$TYPE_HOMEKEY"){
    if ($devNameIndex == "00") { return "Home Key"; }
    elsif ($devNameIndex == "01") { return "Dad's Key"; }
    elsif ($devNameIndex == "02") { return "Mom's Key"; }
    elsif ($devNameIndex == "03") { return "Kid's Key"; }
    elsif ($devNameIndex == "04") { return "Son's Key"; }
    elsif ($devNameIndex == "05") { return "Daughter's Key"; }
    elsif ($devNameIndex == "06") { return "Blue Key"; }
    elsif ($devNameIndex == "07") { return "Red Key"; }
    elsif ($devNameIndex == "08") { return "Green Key"; }
    elsif ($devNameIndex == "09") { return "Yellow Key"; }
    elsif ($devNameIndex == "10") { return "Extra Key"; }
    elsif ($devNameIndex == "11") { return "Neighbor's Key"; }
    else { 
      print ERRORLOG "$date - devNameIndexLookup() had unknown value \"$devNameIndex\" for devType \"$devType\"\n";
      return "Unknown";
    }
  } elsif($devType == "$TYPE_BBGATE"){
    if ($devNameIndex == "00") { return "Gateway Extender"; }
    elsif ($devNameIndex == "01") { return "1st Floor Gateway"; }
    elsif ($devNameIndex == "02") { return "2nd Floor Gateway"; }
    elsif ($devNameIndex == "03") { return "3rd Floor Gateway"; }
    elsif ($devNameIndex == "04") { return "Basement Gateway"; }
    elsif ($devNameIndex == "05") { return "Den Gateway"; }
    elsif ($devNameIndex == "06") { return "Dining Room Gateway"; }
    elsif ($devNameIndex == "07") { return "Front of House"; }
    elsif ($devNameIndex == "08") { return "Garage Gateway"; }
    elsif ($devNameIndex == "09") { return "Hallway Gateway"; }
    elsif ($devNameIndex == "10") { return "Home Office Gateway"; }
    elsif ($devNameIndex == "11") { return "Kitchen Gateway"; }
    elsif ($devNameIndex == "12") { return "Living Room Gateway"; }
    else { 
      print ERRORLOG "$date - devNameIndexLookup() had unknown value \"$devNameIndex\" for devType \"$devType\"\n";
      return "Unknown";
    }

  # We don't know what device code this is currently, or what the name index values are yet
  } elsif($devType == "$TYPE_RANGEX"){
    if ($devNameIndex == "00") { return "Range Extender"; }
    elsif ($devNameIndex == "01") { return "Range Extender 01"; } # This is a guess
    else { 
      print ERRORLOG "$date - devNameIndexLookup() had unknown value \"$devNameIndex\" for devType \"$devType\"\n";
      return "Unknown";
    }

  # We don't know what device code this is currently, or what the name index values are yet
  } elsif($devType == "$TYPE_WATERSHUTOFF"){
    if ($devNameIndex == "00") { return "Water Shut Off Controller"; }
    elsif ($devNameIndex == "01") { return "Soemthing here"; }
    else { 
      print ERRORLOG "$date - devNameIndexLookup() had unknown value \"$devNameIndex\" for devType \"$devType\"\n";
      return "Unknown";
    }

  } elsif($devType == "$TYPE_BASE"){
      return "N/A";
  } elsif($devType == "$TYPE_MODEM"){
      return "N/A";
  }
}

##########################################################

sub checkAlert
{
  my $devAlert = $_[0];
  if($devAlert == "00")
  {
    return "no alert";
  } else {
    if($devAlert == "01"){
        &alertNotify();
        return "alarm triggered"; # controlled by field 9 - $devConfig
    #} elsif($devAlert == "02"){
         # This alert may be tripped when device goes low-battery then dead maby... have not tested...
    #    &alertNotify();
    #    return "off-line, out of range, or batt dead";
    } elsif($devAlert == "03"){
        # This alert was tripped when motion sensor was active in house and then out of range when placed in out-building
        &alertNotify();
        return "off-line";
    } elsif($devAlert == "04"){
        &alertNotify();
        return "low battery";
    } elsif($devAlert == "08"){
        &alertNotify();
        return "battery charging"; # only valid for home key
    } elsif($devAlert == "20"){
        &alertNotify();
        return "running on backup battery"; # only valid for base station
    } else {
        print ERRORLOG "$date - devAlert() had unknown value \"$devAlert\"\n";
        &alertNotify();
        return "unknown alert";
    }
  }
}

sub alertNotify
{
  if($alert != "00000")
  {
    my $AllAlerts = "";
    my @alertC = split("", $alert);
    if(@alertC[0] == "1"){
      $AllAlerts = "Unknown";
      #my $alertUnknown = "1";
    }
    if(@alertC[1] == "1"){
      $AllAlerts = "$AllAlerts, Base Station running on backup battery";
      #my $alertBackupBatt = "1";
    }
    if(@alertC[2] == "1"){
      $AllAlerts = "$AllAlerts, Home Key battery charging";
      #my $alertBattCharge = "1";
    }
    if(@alertC[3] == "1"){
      $AllAlerts = "$AllAlerts, Low sensor battery";
      #my $alertLowBatt = "1";
    }
    if(@alertC[4] == "1"){
      $AllAlerts = "$AllAlerts, Alarm set";
      #my $alertAlarm = "1";
    }
    $AllAlerts =~ s/^ ,//g;

    use Email::MIME;
    my $message = Email::MIME->create(
      header_str => [
      From    => "$emailFrom",
      To      => "$emailTo",
      Subject => "Home Heartbeat Alert from $devName",
    ],
    attributes => {
      encoding => 'quoted-printable',
      charset  => 'ISO-8859-1',
    },
    body_str => "An alert was detected: $devName signaled $AllAlerts.\n",
    );
    use Email::Sender::Simple qw(sendmail);
    sendmail($message);
    print ALERTLOG "$date - Alert email sent for $devName for alert $AllAlerts";
  }
}
