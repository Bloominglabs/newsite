#!/usr/bin/perl
# 2013-11 v0.1 / dosman / Retrieve and display the current state of the Home Heartbeat sensor network
# 2013-12 v0.5 / dosman / Many revisions, updated formatting of output, added use of libraries
#####################################################################################################################

#use strict;
#use warnings;

# Find and use our hh.pm library
use File::Basename qw(dirname);
use Cwd qw(abs_path);
use lib dirname(dirname abs_path $0) . '/hh/lib';

#use HomeHeartbeat::Lookups qw(add);
#use HomeHeartbeat::Lookups qw(devTypeLookup devNameIndexLookup decodeTimer checkAlert devConfigLookup);
use HomeHeartbeat::Lookups qw(useTelnet useSerial printHtmlHeader decodeTimer devTypeLookup devConfigLookup devNameIndexLookup checkAlert alertNotify);

#print add(19, 23);

# 2013-11-18 / dosman / Home Heartbeat script - It digests the state table of the Home Heartbeat base station
# v1.0                  and outputs human readable data. I have not tested the email functionality yet, but the 
#                       other functions work fine. For updates and other info about this script check out this page:
#                       http://bloominglabs.org/index.php/Eaton_Home_Heartbeat
#
#####################################################################################################################
# The Vendor ID for the FTDI chip in the base station is unique to Eaton, but otherwise this is a genric FTDI USB->Serial interface.
# Add a modprobe line for ftdi_sio driver, get vendor and product lines from lsusb:
# echo "options ftdi_sio vendor=0x403 product=0xde29" > /etc/modprobe.d/ftdi_sio.conf
#
# Reload ftdi_sio (or reboot) and it should be picked up correctly now:
# modprobe -r ftdi_sio
# modprobe ftdi_sio
#
#####################################################################################################################
# All field information obtained from this site and my own hardware:
# http://www.kolinahr.com/documentation/home-heartbeat/state-table-of-the-eaton-home-heartbeat/
#
# Output field format:
# STATE="F1,F2,F3,F4,F5,F6,F7,F8,F9,F10,F11,F12,F13,F14,F15,F16,F17"
# STATE="02,00,0040,0002,00,12,00,00,0301,12,0000,00,FF,00000000,00,000D6F0000011367,Home Key"


# Field 1 State Record ID 0 This is a number associated with each device as it's associated with the base station, however it can be changed so do not rely on 
# this. Using "Forget Device" on the home key will cause the devices to renumber.

# Field 2 ZigBee Binding ID 0 This value is an index into the ZigBee Binding Table.

# Field 3 Device Capabilities - field is constant for each device, this field is still not fully understood
$CAPABILITY_UNKNOWN1="01";
$CAPABILITY_UNKNOWN2="02";
$CAPABILITY_SENSOR1="04";
$CAPABILITY_BASESTATION="08";
$CAPABILITY_RECEIVESPARAMS="10"; # Motion, Power, and Reminder sensors
$CAPABILITY_SENSOR2="20";
$CAPABILITY_HOMEKEY="40";
$CAPABILITY_AC="80"; # Base station, modem, and power sensors

# Field 4 Device Type
$TYPE_BASE="0001";
$TYPE_HOMEKEY="0002";
$TYPE_OPENCLOSE="0003";
$TYPE_POWER="0004";
$TYPE_WATER="0005";
$TYPE_REMINDER="0006";
$TYPE_ATTENTION="0007";
$TYPE_MODEM="0010";
$TYPE_MOTION="0017";
$TYPE_TILT="0018";
$TYPE_BBGATE="0012";
# We don't know what values the range extender and water cutoff controller use yet!
$TYPE_RANGEX="null";
$TYPE_WATERSHUTOFF="null";

# Field 5 Device State - This field contains the last reported state of the device.
# Field 6 Device State Timer - This is the elapsed time since the device state has changed.

# Field 7 Device Alerts
$ALARM_TRIGGERED="01";
$DEV_OFFLINE="02"; # device offline, out of range, or battery dead
$BATTERY_LOW="04";
$BATTERY_CHARGING="08"; # only used by home key
$RUNNING_ON_BATTERY="20"; # only used by base station

# Field 8 Device Name Index - This is an index into a predefined list of available names specific to the device type, also Field 17 contains the complete name retrieved out of the index.

# Field 9 Device Configuration
$ALARM1="0001";
$ALARM2="0002";
$CALLME1="0100";
$CALLME2="0200";

# Field 10 Alive Update Timer - This is the elapsed time since that last “I’m Alive” message received from the device.
# Field 11 Update Flags - This field is normally zero (0x00) for all devices. It has been observed to contain the value 0x80 when there is pending data needing to be sent to the device. Please read the description under Field 13: Device Parameter section below.
# Field 12 Undefined
# Field 13 Device Parameter - This field may contain a user selectable configuration value. Only a few devices have the ability to accept a configuration parameter. Power, Reminder, and Motion.
# Field 14 Undefined
# Field 15 Pending Update Timer - This is the elapsed time since the user changed the device configuration parameter defined in Field 13
# Field 16 MAC Address
# Field 17 Device Name

#####################################################################################################################

use Text::Table;
use Getopt::Std;

$outputLog = "/var/log/hh_log.log";
$errorLog = "/var/log/hh.log";
$alertLog = "/var/log/hh.log";

$htmlOut="/opt/www/house/automation/sensors.html";
$fontSize = "6"; # For HTML output on small screens, set font size big

# You can choose what alarm types to be emailed about
# values are or'ed  together
#$alert = "00001"; # Notify on alarm triggered
#$alert = "00010"; # Notify on low battery
#$alert = "00100"; # Notify on battery charging / only homekey does this / why would you care?
#$alert = "01000"; # Notify on base station running on backup battery
#$alert = "10000"; # Notify on any unknown alert types / this would be caused by an alert unknown to this script or a script bug
$alert = "01001"; # Notify on alartm triggered and base station running on backup battery
$emailFrom = 'homeheartbeat@atlas2';
#$emailTo = 'dosman@packetsniffers.org';
$emailTo = 'dosman';


###################################################################################################################
open ERRORLOG, ">>$errorLog" or die $!;
open ALERTLOG, ">>$alertLog" or die $!;

use POSIX qw(tzset);
$ENV{TZ} = 'America/New_York';
tzset;
$date = localtime;

# Only 1 of theese 2 methods should be uncommented, and the chosen method needs to be customized with appropriate values
&useSerial();
#&useTelnet();

sub useSerial
{
 $DEV="/dev/ttyUSB0";
  @stateTable=();
  use Device::SerialPort;
  $port = Device::SerialPort->new("$DEV");
  $port->databits(8);
  $port->baudrate(38400); # All Home-Heartbeat base stations should use this baud rate
  $port->parity("none");
  $port->stopbits(1);

  # Request the state table
  $port->write("S\n");

  while (1)
  {
    my $input = $port->lookfor();
    $input =~ s/\r//g;
    if ($input ne ""){
        # This is where we exclude any weirdness from the serial output - and there appears to be a fair bit of it
        if ($input =~ m/^STATE="/){
            push(@stateTable, "$input");
        }
    }
    if ($input =~ /STATE=DONE/){
      # Dump the STATE=DONE line / no longer needed since we match STATE=" above...
      #pop(@stateTable);
      last;
    }
    $input = "";
  }

}


#####################################################################################################################

my %args;
getopts('rewhd', \%args);
if($args{r}){
  $flag = "r";
  while(scalar(@stateTable) > 0) {
   my $i = shift(@stateTable);
   print $i, "\n"; 
  }
  exit;
} elsif ($args{e}){ # Extended output format
    $flag = "e";
    $tb = Text::Table->new(
        #"Device Type", "Custom Name", "Last Event", "Last Seen", "Alert Status", "Configuration", "Record ID", "Capability ID", "Name Index", "Update Flag", "Device Parameter", "Pending Update Timer", "ZigBee Binding ID", "ZigBee Mac"
        "\nDevice Type", "\nCustom Name", "\nLast Event", "\nLast Seen", "\nAlert Status", "\nConfiguration", "\nRecord ID", "\nAlert", "\nCapability ID", "Name\nIndex", "Update\nFlag", "Device\nParameter", "Pending Update\nTimer", "ZigBee\nBinding ID", "\nZigBee Mac"
    );
} elsif ($args{w}){ # Web/HTML output
    $flag = "w";
} elsif ($args{d}){ # debug output / extra information about the system
    print "This doesn't do anything yet\n";
    $flag = "d";
    exit;
} elsif ($args{h}){
    print "- Home Heartbeat Interface -\n";
    print "This reads the state table from the base station and converts it to human readable format.\n";
    print "This makes it easy to see what the sensors are saying or to more easily feed the data into other scripts.\n";
    print "\nFlags:\n";
    print "        - no flag just gives the most useful output of the state table\n";
    print "-w      - outputs web/html to a file\n";
    print "-r      - just shows the raw state table\n";
    print "-e      - gives an extended output of the state table with more data\n";
    print "-h      - this help screen\n";
    exit;
} else { # default output format
    $tb = Text::Table->new(
        #"Device Type", "Custom Name", "Last Event", "Last Seen", "Alert Status", "Configuration"
        "Sensor Name", "Last Event", "Last Seen", "Alert Status", "Configuration"
    );
}

#####################################################################################################################

while(scalar(@stateTable) > 0)
{
  my $outp = shift(@stateTable);
  my ($recordID, $zigBeeID, $devCap, $devType, $devState, $devStateTimer, $devAlert, $devNameIndex, $devConfig, $aliveUpdateTimer, $updateFlags, $undef1, $devParam, $undef2, $pendUpdateTimer, $macAddr, $devName) = split(',', $outp);
  chomp($devName); # fix dev name
  $devName =~ s/"//g;
  $devName =~ s/\r//g;
  my ($dontCare, $recordID) = split('"', $recordID); # fix recordID, this value doesn't have much use though

 # Skip the base station and modem for default and html output. Modem is worthless now, but base station 
 # can be used to detect power outages if host computer is on UPS and batteries are installed in base station.
 if($flag ne "e"){
   if($devType eq $TYPE_MODEM){ 
     next;
   }
   if($devType eq $TYPE_BASE){
     next;
   }
   if($devType eq $TYPE_HOMEKEY){
     next;
   }
   if($devType eq $TYPE_BBGATE){
     next;
   }
}

# Fill the hopper with data formatted for the appropriate output type
 if ($flag eq "e"){ # extended output
     $tb->load(
       #[ &devTypeLookup($devType), "$devName", &decodeTimer($devStateTimer), &decodeTimer($aliveUpdateTimer), &checkAlert(), &devConfigLookup($devType, $devConfig), $recordID, $devCap, $devNameIndex, $updateFlags, $devParam, $pendUpdateTimer, $zigBeeID, $macAddr ]
       [ &devTypeLookup($devType), &devNameIndexLookup($devType, $devNameIndex), &decodeTimer($devStateTimer), &decodeTimer($aliveUpdateTimer), &checkAlert($devAlert), &devConfigLookup($devType, $devConfig), $recordID, $devAlert, $devCap, $devNameIndex, $updateFlags, $devParam, $pendUpdateTimer, $zigBeeID, $macAddr ]
     );

 } elsif ($flag eq "w"){
    if(! defined $htmlYes){ # Only do this on the first iteration
      &printHtmlHeader();
      $htmlYes = 1;
    }
    print HTMLOUT "<tr><td><font size=$fontSize>$devName</td> <td><font size=$fontSize>";
    print HTMLOUT &decodeTimer($aliveUpdateTimer);
    print HTMLOUT "</td>";

    print HTMLOUT "<td><font size=$fontSize>";
    print HTMLOUT &decodeTimer($devStateTimer);
    print HTMLOUT "</td>";

    print HTMLOUT "<td><font size=$fontSize>";
    print HTMLOUT &checkAlert();
    print HTMLOUT "</td>";

    print HTMLOUT "</tr>\n";

 } else { # default output
   $tb->load(
     #[ &devTypeLookup($devType), "$devName", &decodeTimer($devStateTimer), &decodeTimer($aliveUpdateTimer), &checkAlert(), &devConfigLookup($devType, $devConfig ) ]
     [ &devNameIndexLookup($devType, $devNameIndex), &decodeTimer($devStateTimer), &decodeTimer($aliveUpdateTimer), &checkAlert($devAlert), &devConfigLookup($devType, $devConfig ) ]
   );
 }
} # end foreach

if($flag eq "e"){
     print $tb;
} elsif ($flag eq "w"){
     close HTMLOUT;
} else {
     print $tb;
}

close ERRORLOG;
close ALERTLOG;
