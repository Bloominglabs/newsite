// Y is pins 2-7 (PORTD), X is pins 8-13 (PORTB)
// global variables
byte x, y;   // generic X and Y values
int numDots; // so that we don't spend forever looking for a dot to draw if there are none
byte dots[8][64]; // (8 columns * 8 bits/column) * 64 rows = 1 bit for each possible dot on the screen
unsigned long lastTick; // the last time that the physics were updated
const byte PADDLE_RADIUS = 8; // half the height of a paddle
const byte PADDLE_GAP = 4; // the distance from the edge of the screen to the paddles
const int THRESH = 500; // threshold at which analog inputs trigger. Scale from 0 to 1024
byte rp, lp; // y coordinates of the bottom of the right and left paddles/players. scale from 0 to 63
float bx, by, bs, ba, bxs, bys; //ball x, y, speed, angle, x-speed, and y-speed. scale from 0 to 255
int timer1_counter; // used for interrupt timer

/* Whatever dx and dy are, write those values to the DAC to put the dot there. */
void draw(byte x, byte y){
  // Next time around, make the DAC so that its pins align with the bits of dx and dy, not backwards like it is now!
  // Arduino's digitalWrite() function is actually *very* slow. This project needs to write quickly, so a different method is used.
  // Writing directly to the registers that control the I/O pins is *much* faster.
  // Unfortunately, I didn't know this when I made the DAC, so the bits have to be rearranged a lot in order to make this work.
  //
  // PORTD = 1 1 1 1 1 1 1 1                    PORTB = 1 1 1 1 1 1 1 1
  //         |           | +-- digital pin 0            | | |       | +-- digital pin 8
  //         |           +---- digital pin 2            | | |       +---- digital pin 9
  //         |                 ...                      | | |             ...
  //         +---------------- digital pin 7            | | +------------ digital pin 13
  //                                                    +-+-------------- not used
  // The screen coordinates are as follows:
  // (63,63)                (0,63)
  //        +--------------+
  //        |              |
  //        |              |
  //        |   (dx,dy)    |
  //        |              |
  //        |              |
  //        |              |
  //        +--------------+
  //  (63,0)                (0,0)
  byte portd = (y & 0b00100000)>>3 | 
               (y & 0b00010000)>>1 |
               (y & 0b00001000)<<1 |
               (y & 0b00000100)<<3 |
               (y & 0b00000010)<<5 |
               (y & 0b00000001)<<7;    
  byte portb = (x & 0b00100000)>>5 |
               (x & 0b00010000)>>3 |
               (x & 0b00001000)>>1 |
               (x & 0b00000100)<<1 |
               (x & 0b00000010)<<3 |
               (x & 0b00000001)<<5;
  PORTD = portd;
  PORTB = portb;
}

void clearScreen(){
  numDots=0; // Do this first so that drawNextDot doesn't go into an infinite loop, looking for dots that aren't there...
  for(x=0;x<8;x++){for(y=0;y<64;y++){dots[x][y]=0;}}
}

boolean dotIsOn(byte x, byte y){return bitRead(dots[x>>3][y], x & 0b00000111);}

void turnDotOn(byte x, byte y){
  if(!dotIsOn(x, y)){ dots[x>>3][y] |= bitSet(dots[x>>3][y], x & 0b00000111); numDots++;}
}
void turnDotOff(byte x, byte y){
  if(dotIsOn(x, y)){  dots[x>>3][y] &= bitClear(dots[x>>3][y], x & 0b00000111); numDots--;}
}

// Create a random integer from 0 - 65535. Based on http://engineeringnotes.blogspot.com/2015/07/a-fast-random-function-for-arduinoc.html
// I have turned this into a *terrible* random number generator, but it is fast.
unsigned int rng() {
  static unsigned int rnd;
  rnd += 1; rnd ^= rnd << 2; rnd ^= rnd >> 7;
  return (rnd);
}

void drawNextDot(){
  static byte dx, dy;
  if(numDots>0){
    noInterrupts();
    unsigned int rnd;
//    do{dx++; if(dx>=64){ dx=0; dy++; if(dy>=64){dy=0;} }}
//    do{dx=random(64); dy=random(64);}
    do{
      rnd=rng(); // a 16-bit random number
      dy=(rnd>>8) & 0b00111111; // 8 bits into dy
      dx=     rnd & 0b00111111; // and 8 bits into dx
    }
    while(!dotIsOn(dx, dy));
    draw(dx, dy);
    interrupts();
  }
}

/* reads the player inputs, moves the paddles if necessary, and performs a minimal pixel change */
void updatePaddles(){
  static boolean lpu, lpd, rpu, rpd; // [right | left] player [up | down]
  lpu=analogRead(2)>THRESH && lp+PADDLE_RADIUS<63; lpd=analogRead(3)>THRESH && lp-PADDLE_RADIUS>0;
  rpu=analogRead(0)>THRESH && rp+PADDLE_RADIUS<63; rpd=analogRead(1)>THRESH && rp-PADDLE_RADIUS>0;
  if(lpu){ // left player up
      turnDotOff(63-PADDLE_GAP, lp-PADDLE_RADIUS);
      lp++;
      turnDotOn(63-PADDLE_GAP, lp+PADDLE_RADIUS-1);
    } else if(lpd) { // left player down
      turnDotOff(63-PADDLE_GAP, lp+PADDLE_RADIUS-1);
      lp--;
      turnDotOn(63-PADDLE_GAP, lp-PADDLE_RADIUS);
    }

  if(rpu){ // right player up
      turnDotOff(PADDLE_GAP, rp-PADDLE_RADIUS);
      rp++;
      turnDotOn(PADDLE_GAP, rp+PADDLE_RADIUS-1);
    } else if(rpd){ // right player down
      turnDotOff(PADDLE_GAP, rp+PADDLE_RADIUS-1);
      rp--;
      turnDotOn(PADDLE_GAP, rp-PADDLE_RADIUS);
    }
}

void drawPaddles(){
  for(y=rp-PADDLE_RADIUS; y<rp+PADDLE_RADIUS; y++){turnDotOn(PADDLE_GAP, y);} // right player
  for(y=lp-PADDLE_RADIUS; y<lp+PADDLE_RADIUS; y++){turnDotOn(63-PADDLE_GAP, y);} // left player
}

void updateBall(){
  // normal, free movement
  turnDotOff((byte)bx, (byte)by);
  bx += bxs;
  by += bys;
  turnDotOn((byte)bx, (byte)by);
  
  // bounce off the top and bottom
  if(by>63){
    ba=(3.14*2)-ba;
    bxs = bs*cos(ba);
    bys = bs*sin(ba);
    by=63;
  }
  if(by<0){
    ba=(3.14*2)-ba;
    bxs = bs*cos(ba);
    bys = bs*sin(ba);
    by=0;
  }

  // hit left or right wall
  if(bx<=0 || bx >= 63){
    delay(500);
    resetGame();
  }

  // hit right paddle
  if(PADDLE_GAP <= bx && PADDLE_GAP+(1.5*abs(bxs)) >= bx && by >= rp-PADDLE_RADIUS-1.0 && by <= rp+PADDLE_RADIUS && bxs<0){
    ba=3.14-ba-((float)(rp-by))/((float)PADDLE_RADIUS);
    bs += 0.05;
    bxs = bs*cos(ba);
    bys = bs*sin(ba);
    drawPaddles();
  }

  // hit left paddle
  if(63-PADDLE_GAP-(1.5*abs(bxs)) <= bx && 63-PADDLE_GAP >= bx && by >= lp-PADDLE_RADIUS-1.0 && by <= lp+PADDLE_RADIUS && bxs>0){
    ba=3.14-ba-((float)(lp-by))/((float)PADDLE_RADIUS);
    bs += 0.05;
    bxs = bs*cos(ba);
    bys = bs*sin(ba);
    drawPaddles();
  }
}

void resetGame(){
  clearScreen();
  // set up the paddles
  rp = (64/2) - PADDLE_RADIUS;
  lp = (64/2) - PADDLE_RADIUS;
  drawPaddles();  // without this, the paddles would be invisible until they moved

  // set up the ball
  lastTick = millis();
  randomSeed(millis());
  bx=32; by=32; bs=0.3; ba=(((float)random(157))/100.0)-0.85 + (3.14 * (float)random(2));
  bxs = bs*cos(ba);
  bys = bs*sin(ba);
}

void setup() {
  // set up output pins for DAC
  for(byte p=2; p<=13; p++){pinMode(p, OUTPUT); digitalWrite(p, LOW);}
  
  // BEFORE DRAWING: enable timer interrupt for drawNextDot()
  // taken from http://www.hobbytronics.co.uk/arduino-timer-interrupts
  TCCR1A = 0;
  TCCR1B = 0;
  timer1_counter = 65520;//65535;
  TCCR1B |= (1 << CS12);    // 256 prescaler 
  TIMSK1 |= (1 << TOIE1);   // enable timer overflow interrupt

  // let the operator calibrate the screen
  turnDotOn(32,32);
  for(x=0;x<64;x++){turnDotOn(x,0);turnDotOn(x,63);}
  for(y=0;y<64;y++){turnDotOn(0,y);turnDotOn(63,y);}
  while(analogRead(0)<THRESH && analogRead(1)<THRESH && analogRead(2)<THRESH && analogRead(3)<THRESH){}

  // play pong!
  resetGame();
}
ISR(TIMER1_OVF_vect)        // interrupt service routine 
{
  TCNT1 = timer1_counter;   // preload timer
  drawNextDot();
}

void loop() {
  updatePaddles();
  updateBall();
}
