/*

6-13-10 / NTH / read the value of a trimpot in, print a value from 0 to 9 out serial/RFlink
7-23-10 /SDC some minor edits

 */

#define TRANSMITTER
//#include <LiquidCrystal.h>

//LiquidCrystal lcd(7, 8, 9, 10, 11, 12);
// sez above has no matching function.

int analogPin = 3;     // potentiometer wiper (middle terminal) connected to analog pin 3 - outside leads to ground and +5V
int val = 0;           // variable to store the value read
int tot = 0;
int out = 0;
int ledPin = 6;

unsigned long lastChangeTime = 0; // last time something happened
unsigned int interval = 500; // time in millis between doing things
boolean lightOn = false;

void setup()
{
  pinMode(ledPin, OUTPUT);
  Serial.begin(300);          //  setup serial

//  lcd.begin(16, 2);            //  setup LCD
//  lcd.setCursor(0, 0);
//  lcd.print("TrimPot Value:");
}

void blink() {
  if (millis() - lastChangeTime > interval) {
    lightOn = !lightOn;
    if (lightOn)
      digitalWrite(ledPin, HIGH);
    else
      digitalWrite(ledPin, LOW);
    lastChangeTime = millis(); // mark our point in time for future comparison
  }
}

void loop()
{
  for (int i=0; i<= 19; i++){
    val = analogRead(analogPin);    // read the input pin
    tot = tot + val;
  }
  val = tot / 20;
  tot = 0;
  delay(50);

  out = map(val, 0, 1024, 0, 10); // take a value from 0 -> 1024, map it from 0 to 9

  writeUInt(out); // send our averaged value to the transmitter
  interval = map(out, 0, 9, 500, 50); // as input goes 0 -> 9, delay goes 500-50
  blink();

 // lcd.setCursor(0, 1);
 // lcd.print(out);
  out = 0;
}
