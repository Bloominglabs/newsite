// Maurice Ribble 
// 8-30-2009
// http://www.glacialwanderer.com/hobbyrobotics
// Used Arduino 0017
// This is a simple test app for some cheap RF transmitter and receiver hardware.
// RF Transmitter: http://www.sparkfun.com/commerce/product_info.php?products_id=8945
// RF Receiver: http://www.sparkfun.com/commerce/product_info.php?products_id=8948
/*
7/25/2010 - SDC Some additions for the sensor value triggering an LED variation.
*/

// This says whether you are building the transmistor or reciever.
// Only one of these should be defined.
//#define TRANSMITTER
#define RECEIVER

// for transmitter/receiver, note that 
// RX is digital pin 0 (ATmega328 pin 2)
// TX is digital pin 1 (ATmega328 pin 3)

// Arduino digital pins
#define LED_PIN     6

// do something if the value you get goes above this.
int threshold = 300;
int serial_rate = 1200; // Hardware supports up to 2400, but 1200 gives longer range

int analogPin = 3;     // potentiometer wiper (middle terminal) connected to analog pin 3 - outside leads to ground and +5V
int val = 0;           // variable to store the value read
int tot = 0;

unsigned long lastChangeTime = 0; // last time something happened
unsigned int interval = 500; // time in millis between doing things
boolean lightOn = false;

void setup()
{

  pinMode(LED_PIN, OUTPUT);
  digitalWrite(LED_PIN, LOW);
  Serial.begin(serial_rate);  

}

#ifdef RECEIVER

/*

example of function checking to see if the value is above the threshold,
in which case the light is turned on...

*/

void take_action(int myvar) {
  if (!lightOn && myvar>threshold) {
   lightOn = true; 
   digitalWrite(LED_PIN, HIGH);
  } else if (myvar <= threshold && lightOn) {
   lightOn = false; 
   digitalWrite(LED_PIN, LOW);
  }  
}

void loop()
{
    val = readUInt(true);
    take_action(val);
    Serial.println(val);
}

#endif //RECEIVER

#ifdef TRANSMITTER

/*

6-13-10 / NTH / read the value of a trimpot in, print a value from 0 to 9 out serial/RFlink
7-23-10 /SDC some minor edits - read a general analog input, just send out the raw value
LED blinks faster as the value gets higher.

 */

void blink() {
  if (millis() - lastChangeTime > interval) {
    lightOn = !lightOn;
    if (lightOn)
      digitalWrite(LED_PIN, HIGH);
    else
      digitalWrite(LED_PIN, LOW);
    lastChangeTime = millis(); // mark our point in time for future comparison
  }
}

void loop()
{
  for (int i=0; i<= 19; i++){
    val = analogRead(analogPin);    // read the input pin
    tot = tot + val;
  }
  val = tot / 20;
  tot = 0;
  delay(50);

  writeUInt(val); // send our averaged value to the transmitter 0 - 1024
  interval = map(val, 0, 1024, 500, 50); // as input goes 0 -> 1024, delay goes 500 -> 50
  blink();
}

#endif // TRANSMITTER
