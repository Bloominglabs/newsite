/*

This is barebones code to show analog readings (for finding thresholds and such)

 */

int analogPin = 3;     // potentiometer wiper (middle terminal) connected to analog pin 3 - outside leads to ground and +5V
int val = 0;           // variable to store the value read
int tot = 0;          // use to sum up values.

void setup()
{
  Serial.begin(9600);          //  setup serial
}

void loop()
{
  // get 20 readings, average them.
  for (int i=0; i<= 19; i++){
    val = analogRead(analogPin);    // read the input pin
    tot = tot + val;
  }
  val = tot / 20;
  tot = 0;
  Serial.println(val);
  delay(50);
}
