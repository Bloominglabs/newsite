/*
* Simple Receiver Code
* (TX out of Arduino is Digital Pin 1)
* (RX into Arduino is Digital Pin 0)
*/
int incomingByte = 0;
void setup(){
//2400 baud for the 434 model
Serial.begin(1200);
}
void loop(){
// read in values, debug to computer
if (Serial.available() > 0) {
  incomingByte = Serial.read();
  if (incomingByte >= 9 && incomingByte <= 122)
    Serial.print(incomingByte,BYTE);
  incomingByte = 0;
  }
}
