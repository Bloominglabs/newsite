// ***********************************************************
// Project: A silly counter using interrupts
// Author: Charles Hart
// Module description: Count the number of rising edges on (INT0)/PD2
//                              Output this number on PORTB
// ***********************************************************
 
#include <avr/io.h>              
#include <util/delay.h>

 
// ***********************************************************
// Main program
//
int main(void)
{
    //initialization of ports and interrupts
    //p. 58 SFIOR details
        TCCR2 = 0x72;   // set phase correct PWM for timer 2
        OCR2 =  100;    // set starting duty cycle for timer 2 - pin PD7

        // init stuff for the 16 bit timer
    TCCR1A  = 0xA2;             // 0xFX versus 0xAX to invert waveform
    //TCCR1B  = 0x19;           // 0x19 for 20ms prescaler
    ICR1    = 20000;    // TOP value of counter set at 20ms (base freq = 50Hz)
    /*OCR1A   = 1500;           // Starting duty cycle (1500=center) motor A - pin PD5
    OCR1B   = 1500;             // Starting duty cycle (1500=center) motor B - pin PD4    

        // set output pins
        //DDRD  = 0xB0;     // set output bits (OCR 1A 1B & motor 2 compare)
        DDRB  = 0x08;     // set output motor 1

    SFIOR &= ~(1 << PUD); //ensure pull-up-disable is disabled
    DDRD = 0xFF; //(0 << PD2); //PD2 as input
    //PORTD = 0xFF; //set internal pull-ups on
 
  
   while(1) //infinite looooooooooooooooooooooooooop
   {
     PORTD += 1;
         _delay_ms(500);
   }*/
    return 1;
}
