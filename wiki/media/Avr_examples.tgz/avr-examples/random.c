#define F_CPU 1000000UL
#include <stdlib.h>
#include <avr/io.h>
#include <util/delay.h>

void init_chip(void) {

  DDRB=0x0F;
  DDRD=0x00;
  PORTD=0xFF;
}

void main(void) {
  int roll=0;
  
  init_chip();

  _delay_loop_2(5000);

  while(1) {
    if((PIND & 0x01) == 0) {
      PORTB = 0xFF;
      roll = rand(); 
   } else {
      PORTB = roll;
   }
    _delay_loop_2(5000);
  }
}
