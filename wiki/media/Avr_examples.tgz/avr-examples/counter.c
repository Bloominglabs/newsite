// ***********************************************************
// Project: A silly counter using interrupts
// Author: Charles Hart
// Module description: Count the number of rising edges on (INT0)/PD2
//                              Output this number on PORTB
// ***********************************************************

#define F_CPU 1000000UL
 
#include <avr/io.h>              
#include <avr/interrupt.h>    
#include <util/delay.h>

 
char state;

ISR(INT0_vect)
{
   if ((PORTD & 0x03)==0)
      PORTD |= 0x03;
   else
      PORTD &= 0xFC;
   // Disable INT0 to avoid button bounces
   GICR &= ~(1 << INT0);
}
 
// ***********************************************************
// Main program
//
int main(void)
{
    //initialization of ports and interrupts
    //p. 58 SFIOR details
    SFIOR &= ~(1 << PUD); //ensure pull-up-disable is disabled
    DDRD = 0x03; //(0 << PD2); //PD2 as input
    PORTD = 0x00; //set internal pull-ups on
    //while(1){}
 
    //interrupts covered on p.66 of atmega8 datasheet
    MCUCR |= (1 << ISC01) | (1 << ISC00); // rising edge trigger
    GICR |= (1 << INT0);                         // enable INT0
 
    sei(); //enable interrupts
   
   while(1) //infinite looooooooooooooooooooooooooop
   {
     // If INT0 is off, then turn it back on after waiting a bit
     if((GICR & (1 << INT0)) == 0) {
       // Wait a couple hundred ms for button to stop bouncing
       _delay_loop_2(60000);

       // Clear any waiting interrupts and enable
       GIFR |= (1 << INTF0); // Clear
       GICR |= (1 << INT0); // Enable
     }
   }
    return 1;
}

