<?php require_once('Connections/eam.php'); ?>
<?php // Enterprise Asset Management - Graham Fisk - BigSmallweb.com - 2012 // 
      // 1-4-12 / dosman / modified to support QR code asset tags

$currentPage = $_SERVER["PHP_SELF"];

include "phpqrcode/qrlib.php";

$maxRows_rsHardwareAssets = 10000;
$pageNum_rsHardwareAssets = 0;
if (isset($_GET['pageNum_rsHardwareAssets'])) {
  $pageNum_rsHardwareAssets = $_GET['pageNum_rsHardwareAssets'];
}
$startRow_rsHardwareAssets = $pageNum_rsHardwareAssets * $maxRows_rsHardwareAssets;

mysql_select_db($database_eam, $eam);
$query_rsHardwareAssets = "SELECT * FROM assets_hardware";
$query_limit_rsHardwareAssets = sprintf("%s LIMIT %d, %d", $query_rsHardwareAssets, $startRow_rsHardwareAssets, $maxRows_rsHardwareAssets);
$rsHardwareAssets = mysql_query($query_limit_rsHardwareAssets, $eam) or die(mysql_error());
//$row_rsHardwareAssets = mysql_fetch_assoc($rsHardwareAssets);
$row_rsHardwareAsset = mysql_fetch_assoc($rsHardwareAssets);

if (isset($_GET['totalRows_rsHardwareAssets'])) {
  $totalRows_rsHardwareAssets = $_GET['totalRows_rsHardwareAssets'];
} else {
  $all_rsHardwareAssets = mysql_query($query_rsHardwareAssets);
  $totalRows_rsHardwareAssets = mysql_num_rows($all_rsHardwareAssets);
}
$totalPages_rsHardwareAssets = ceil($totalRows_rsHardwareAssets/$maxRows_rsHardwareAssets)-1;

mysql_select_db($database_eam, $eam);
$query_rsVendors = "SELECT * FROM vendors";
$rsVendors = mysql_query($query_rsVendors, $eam) or die(mysql_error());
$row_rsVendors = mysql_fetch_assoc($rsVendors);
$totalRows_rsVendors = mysql_num_rows($rsVendors);

mysql_select_db($database_eam, $eam);
$query_rsPlatform = "SELECT * FROM assets_hardware_platform";
$rsPlatform = mysql_query($query_rsPlatform, $eam) or die(mysql_error());
$row_rsPlatform = mysql_fetch_assoc($rsPlatform);
$totalRows_rsPlatform = mysql_num_rows($rsPlatform);

$colname_rsHardwareUpdate = "-1";
if (isset($_GET['recordID'])) {
  $colname_rsHardwareUpdate = (get_magic_quotes_gpc()) ? $_GET['recordID'] : addslashes($_GET['recordID']);
}
mysql_select_db($database_eam, $eam);
$query_rsHardwareUpdate = sprintf("SELECT * FROM assets_hardware WHERE asset_hardware_id = %s", $colname_rsHardwareUpdate);
$rsHardwareUpdate = mysql_query($query_rsHardwareUpdate, $eam) or die(mysql_error());
$row_rsHardwareUpdate = mysql_fetch_assoc($rsHardwareUpdate);
$totalRows_rsHardwareUpdate = mysql_num_rows($rsHardwareUpdate);

mysql_select_db($database_eam, $eam);
$query_rsDivision = "SELECT * FROM division";
$rsDivision = mysql_query($query_rsDivision, $eam) or die(mysql_error());
$row_rsDivision = mysql_fetch_assoc($rsDivision);
$totalRows_rsDivision = mysql_num_rows($rsDivision);

mysql_select_db($database_eam, $eam);
$query_rsHardwareType = "SELECT * FROM assets_hardware_type";
$rsHardwareType = mysql_query($query_rsHardwareType, $eam) or die(mysql_error());
$row_rsHardwareType = mysql_fetch_assoc($rsHardwareType);
$totalRows_rsHardwareType = mysql_num_rows($rsHardwareType);

mysql_select_db($database_eam, $eam);
$query_rsLocation = "SELECT * FROM location";
$rsLocation = mysql_query($query_rsLocation, $eam) or die(mysql_error());
$row_rsLocation = mysql_fetch_assoc($rsLocation);
$totalRows_rsLocation = mysql_num_rows($rsLocation);

mysql_select_db($database_eam, $eam);
$query_rsHardwareStatus = "SELECT * FROM assets_hardware_status";
$rsHardwareStatus = mysql_query($query_rsHardwareStatus, $eam) or die(mysql_error());
$row_rsHardwareStatus = mysql_fetch_assoc($rsHardwareStatus);
$totalRows_rsHardwareStatus = mysql_num_rows($rsHardwareStatus);

$queryString_rsHardwareAssets = "";
if (!empty($_SERVER['QUERY_STRING'])) {
  $params = explode("&", $_SERVER['QUERY_STRING']);
  $newParams = array();
  foreach ($params as $param) {
    if (stristr($param, "pageNum_rsHardwareAssets") == false && 
        stristr($param, "totalRows_rsHardwareAssets") == false) {
      array_push($newParams, $param);
    }
  }
  if (count($newParams) != 0) {
    $queryString_rsHardwareAssets = "&" . htmlentities(implode("&", $newParams));
  }
}
$queryString_rsHardwareAssets = sprintf("&totalRows_rsHardwareAssets=%d%s", $totalRows_rsHardwareAssets, $queryString_rsHardwareAssets); 

if (isset($_GET['size'])) {
  $tagSize = (get_magic_quotes_gpc()) ? $_GET['size'] : addslashes($_GET['size']);
  if ($tagSize == 'S') {
    $tagSize = 'S';
  }
}
if ($tagSize != 'S') {
    $tagSize = 'L';
}
$tag = "Tag$tagSize.php";
?>

<?php $pageTitle="Asset Tag List"; ?>

    <table class="table1">
      <tr>
      </tr>
      <?php do { ?>

<?php include("$tag"); ?>
          </fieldset>
	 </td>
        <td valign="top" style="font-size:90%;">
          <p>&nbsp;</p>
        </td>
      </tr>

<!--
    <table border="0" align="left" cellspacing="0" class="tableDetails1" style"margin:0 auto;width 600px;">
      <tr>
        <td style="font-size:100%">
          <fieldset>
          <legend><?php echo $row_rsHardwareAsset['asset_type']; ?></legend>
          <table class="tableDetails">
            <tr>
              <th rowspan="6">
              <img src="AssetQR.php?recordID=<?php echo $row_rsHardwareAsset['asset_hardware_id']; ?>">
              </th>
            </tr>
            <tr>
              <th align="left"><span style="font-weight: bold">Make</span></th>
              <td><?php echo $row_rsHardwareAsset['vendor']; ?> &nbsp;</td>
            </tr>
            <tr>
              <th align="left"><span style="font-weight: bold">Model</span></th>
              <td><?php echo $row_rsHardwareAsset['model']; ?> &nbsp;</td>
            </tr>
            <tr>
              <th align="left"><span style="font-weight: bold">Asset ID</span></th>
              <td><?php echo $row_rsHardwareAsset['asset_hardware_id']; ?> &nbsp;</td>
            </tr>
            <tr>
              <th align="left">Owner</th>
              <td><?php echo $row_rsHardwareAsset['user']; ?> &nbsp;</td>
            </tr>
            <tr>
              <th align="left">Training</th>
              <td><?php echo $row_rsHardwareAsset['division']; ?> &nbsp;</td>
            </tr>
          </table>
        </tr>
-->
      <?php } while ($row_rsHardwareAsset = mysql_fetch_assoc($rsHardwareAssets)); ?>

    </table>
</table>	

<?php
mysql_free_result($rsHardwareAssets);

mysql_free_result($rsVendors);

mysql_free_result($rsPlatform);

mysql_free_result($rsHardwareUpdate);

mysql_free_result($rsDivision);

mysql_free_result($rsHardwareType);

mysql_free_result($rsLocation);

mysql_free_result($rsHardwareStatus);
?>
