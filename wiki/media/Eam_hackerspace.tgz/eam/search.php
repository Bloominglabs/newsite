<?php require_once('Connections/eam.php'); ?>
<?php // Enterprise Asset Management - Graham Fisk - BigSmallweb.com - 2012 // 
mysql_select_db($database_eam, $eam);
$query_rsVendors = "SELECT * FROM vendors ORDER BY vendor ASC";
$rsVendors = mysql_query($query_rsVendors, $eam) or die(mysql_error());
$row_rsVendors = mysql_fetch_assoc($rsVendors);
$totalRows_rsVendors = mysql_num_rows($rsVendors);

mysql_select_db($database_eam, $eam);
$query_rsPlatforms = "SELECT * FROM assets_hardware_platform ORDER BY platform ASC";
$rsPlatforms = mysql_query($query_rsPlatforms, $eam) or die(mysql_error());
$row_rsPlatforms = mysql_fetch_assoc($rsPlatforms);
$totalRows_rsPlatforms = mysql_num_rows($rsPlatforms);

mysql_select_db($database_eam, $eam);
$query_rsHardwareType = "SELECT * FROM assets_hardware_type";
$rsHardwareType = mysql_query($query_rsHardwareType, $eam) or die(mysql_error());
$row_rsHardwareType = mysql_fetch_assoc($rsHardwareType);
$totalRows_rsHardwareType = mysql_num_rows($rsHardwareType);

mysql_select_db($database_eam, $eam);
$query_rsAssets = "SELECT DISTINCT model FROM assets_hardware ORDER BY model ASC";
$rsAssets = mysql_query($query_rsAssets, $eam) or die(mysql_error());
$row_rsAssets = mysql_fetch_assoc($rsAssets);
$totalRows_rsAssets = mysql_num_rows($rsAssets);

mysql_select_db($database_eam, $eam);
$query_rsDivisionList = "SELECT * FROM division";
$rsDivisionList = mysql_query($query_rsDivisionList, $eam) or die(mysql_error());
$row_rsDivisionList = mysql_fetch_assoc($rsDivisionList);
$totalRows_rsDivisionList = mysql_num_rows($rsDivisionList);

mysql_select_db($database_eam, $eam);
$query_rsHardwareStatus = "SELECT * FROM assets_hardware_status";
$rsHardwareStatus = mysql_query($query_rsHardwareStatus, $eam) or die(mysql_error());
$row_rsHardwareStatus = mysql_fetch_assoc($rsHardwareStatus);
$totalRows_rsHardwareStatus = mysql_num_rows($rsHardwareStatus);
 
$pageTitle="Search"; ?>
<?php include('includes/header.php'); ?>
<fieldset>
<legend>Search Assets</legend>
<form id="searchAssets" name="searchAssets" method="post" action="searchResults.php">
  <table class="tableSearch">
<!-- 1-4-13 - dosman - added asset id num search
-->
	<tr>
	  <th>Asset ID</th>
	  <td>
	    <input type="text" name="asset_hardware_id" />
	  </td>
	  <td>
	    <input type="submit" name="Submit" value="Search" />
	  </td>
	</tr>
	<tr>
	  <th>Serial Number</th>
	  <td>
	    <input type="text" name="serialnumber" />
	  </td>
	  <td>
	    <input type="submit" name="Submit" value="Search" />
	  </td>
	</tr>
	<tr>
      <th>Vendor</th>
	  <td>
        <select name="vendor" id="vendor">
          <option value="value">Select Vendor</option>
          <?php
do {  
?>
          <option value="<?php echo $row_rsVendors['vendor']?>"><?php echo $row_rsVendors['vendor']?></option>
          <?php
} while ($row_rsVendors = mysql_fetch_assoc($rsVendors));
$rows = mysql_num_rows($rsVendors);
if($rows > 0) {
  mysql_data_seek($rsVendors, 0);
  $row_rsVendors = mysql_fetch_assoc($rsVendors);
}
?>
        </select>
      </td>
	  <td>
        <input type="submit" name="Submit" value="Search" />
      </td>
	  </tr>

	<tr>
	  <th>Model </th>
	  <td>
	    <select name="model" id="model">
		<option value="value">Select Model</option>
	      <?php
do {  
?>
	      <option value="<?php echo $row_rsAssets['model']?>"><?php echo $row_rsAssets['model']?></option>
	      <?php
} while ($row_rsAssets = mysql_fetch_assoc($rsAssets));
  $rows = mysql_num_rows($rsAssets);
  if($rows > 0) {
      mysql_data_seek($rsAssets, 0);
	  $row_rsAssets = mysql_fetch_assoc($rsAssets);
  }
?>
	      </select>
	    </td>
	  <td>
	    <input type="submit" name="Submit" value="Search" />
	  </td>
	  </tr>
	

	<tr>
	  <th>Category</th>
	  <td>
	    <select name="platform" id="platform">
		  <option value="">Select Category</option>
		  <?php
do {  
?>
		  <option value="<?php echo $row_rsPlatforms['platform']?>"><?php echo $row_rsPlatforms['platform']?></option>
		  <?php
} while ($row_rsPlatforms = mysql_fetch_assoc($rsPlatforms));
$rows = mysql_num_rows($rsPlatforms);
if($rows > 0) {
  mysql_data_seek($rsPlatforms, 0);
  $row_rsPlatforms = mysql_fetch_assoc($rsPlatforms);
}
?>
		  </select>
	  </td>
	  <td>
	    <input type="submit" name="Submit" value="Search" />
	  </td>
	</tr>
	

	<tr>
	  <th>Asset Type</th>
	  <td>
	    <select name="asset_type" id="asset_type">
		  <option value="">Select Type </option>
		  <?php
do {  
?>
		  <option value="<?php echo $row_rsHardwareType['assets_hardware_type']?>"><?php echo $row_rsHardwareType['assets_hardware_type']?></option>
		  <?php
} while ($row_rsHardwareType = mysql_fetch_assoc($rsHardwareType));
$rows = mysql_num_rows($rsHardwareType);
if($rows > 0) {
  mysql_data_seek($rsHardwareType, 0);
  $row_rsHardwareType = mysql_fetch_assoc($rsHardwareType);
}
?>
		  </select>
	  </td>
	  <td>
	    <input type="submit" name="Submit" value="Search" />
	  </td>
	</tr>

<!-- Division/Training search
-->
	<tr>
	  <th>Training</th>
	  <td>
	    <select name="division" id="division">
		  <option value="">Select Training </option>
		  <?php
do {  
?>
		  <option value="<?php echo $row_rsDivisionList['division']?>"><?php echo $row_rsDivisionList['division']?></option>
		  <?php
} while ($row_rsDivisionList = mysql_fetch_assoc($rsDivisionList));
$rows = mysql_num_rows($rsDivisionList);
if($rows > 0) {
  mysql_data_seek($rsDivisionList, 0);
  $row_rsDivisionList = mysql_fetch_assoc($rsDivisionList);
}
?>
		  </select>
	  </td>
	  <td>
	    <input type="submit" name="Submit" value="Search" />
	  </td>
	</tr>

<!-- Status search
-->
	<tr>
	  <th>Status</th>
	  <td>
	    <select name="status" id="status">
		  <option value="">Select Status </option>
		  <?php
do {  
?>
		  <option value="<?php echo $row_rsHardwareStatus['assets_hardware_status']?>"><?php echo $row_rsHardwareStatus['assets_hardware_status']?></option>
		  <?php
} while ($row_rsHardwareStatus = mysql_fetch_assoc($rsHardwareStatus));
$rows = mysql_num_rows($rsHardwareStatus);
if($rows > 0) {
  mysql_data_seek($rsHardwareStatus, 0);
  $row_rsHardwareStatus = mysql_fetch_assoc($rsHardwareStatus);
}
?>
		  </select>
	  </td>
	  <td>
	    <input type="submit" name="Submit" value="Search" />
	  </td>
	</tr>

<!-- Purchase date search
-->
	<tr>
      <th>Purchase Date</th>
	  <td>
            <input type="text" name="date_purchase" value="" size="10" />
            <img src='images/scw.gif' title='Click Here' alt='Click Here' onclick="cal.select(document.forms['searchAssets'].date_purchase,'anchor2','MM/dd/yyyy'); return false;" name="anchor2" id="anchor2" style="cursor:hand" />
           </td>
	  <td>
        <input type="submit" name="Submit" value="Search" />
      </td>
	  </tr>
<!-- ---------------------------
-->

	<tr>
      <th>Owner (Full Name) </th>
	  <td>
        <input type="text" name="user" />
      </td>
	  <td>
        <input type="submit" name="Submit" value="Search" />
      </td>
	  </tr>
<!--
	<tr>
      <th>Domain Account </th>
	  <td>
        <input type="text" name="user_account" />
      </td>
	  <td>
        <input type="submit" name="Submit" value="Search" />
      </td>
	  </tr>
-->
	<tr>
	  <th>Location </th>
	  <td>
	    <input name="location" type="text" id="location" />
	  </td>
	  <td>
	    <input type="submit" name="Submit" value="Search" />
	  </td>
	  </tr>
  </table>
</form>
</fieldset>
<?php include('includes/footer.php'); ?>
<?php
mysql_free_result($rsVendors);

mysql_free_result($rsPlatforms);

mysql_free_result($rsHardwareType);

mysql_free_result($rsAssets);

/* mysql_free_results($rsDivisionList); */

?>
