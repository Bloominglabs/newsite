<?php require_once('Connections/eam.php'); ?>
<!-- This is the small size asset tag
-->
    <table border="0" align="left" cellspacing="0" class="tableDetails1" style"margin:0 auto;width 600px">
      <tr>
        <td style="font-size:20%">
          <fieldset>
          <legend><?php echo $row_rsHardwareAsset['asset_type']; ?></legend>
          <table class="tableDetails">

            <tr>
              <th rowspan="6">
                <img src="AssetQR.php?recordID=<?php echo $row_rsHardwareAsset['asset_hardware_id']; ?>&size=<?php echo $tagSize; ?>">
              </th>
            </tr>
            <tr>
              <th align="left" style="font-size:20%"><span style="font-weight: bold">Make</span></th>
              <td style="font-size:20%"><?php echo $row_rsHardwareAsset['vendor']; ?> &nbsp;</td>
            </tr>
            <tr>
              <th align="left" style="font-size:20%"><span style="font-weight: bold">Model</span></th>
              <td style="font-size:20%"><?php echo $row_rsHardwareAsset['model']; ?> &nbsp;</td>
            </tr>
            <tr>
              <th align="left" style="font-size:20%"><span style="font-weight: bold">Asset ID</span></th>
              <td style="font-size:20%"><?php echo $row_rsHardwareAsset['asset_hardware_id']; ?> &nbsp;</td>
            </tr>
            <tr>
              <th align="left" style="font-size:20%" height="5">Owner</th>
              <td style="font-size:20%"><?php echo $row_rsHardwareAsset['user']; ?> &nbsp;</td>
            </tr>
            <tr>
              <th align="left" style="font-size:20%" height="5">Training</th>
              <td style="font-size:20%"><?php echo $row_rsHardwareAsset['division']; ?> &nbsp;</td>
            </tr>

            <tr>
              <th colspan="3" align="center" style="font-size:20%" height="5"><span style="font-weight: normal">https://www.bloominglabs.org/assets</th>
            </tr>
        </table>
