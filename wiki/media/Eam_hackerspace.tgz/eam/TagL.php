<?php require_once('Connections/eam.php'); ?>
<!-- This is the large size asset tag
-->
    <table border="0" align="left" cellspacing="0" class="tableDetails1" style"margin:0 auto;width 600px;">
      <tr>
        <td style="font-size:100%">
          <fieldset>
          <legend>  <?php echo $row_rsHardwareAsset['asset_type']; ?> </legend>
          <table class="tableDetails">

            <tr>
              <th rowspan="6">
		<img src="AssetQR.php?recordID=<?php echo $row_rsHardwareAsset['asset_hardware_id']; ?>&size=<?php echo $tagSize; ?>">
              </th>
            </tr>
            <tr>
              <th align="left"><span style="font-weight: bold">Make</span></th>
              <td><?php echo $row_rsHardwareAsset['vendor']; ?> &nbsp;</td>
            </tr>
            <tr>
              <th align="left"><span style="font-weight: bold">Model</span></th>
              <td><?php echo $row_rsHardwareAsset['model']; ?> &nbsp;</td>
            </tr>
            <tr>
              <th align="left"><span style="font-weight: bold">Asset ID</span></th>
              <td><?php echo $row_rsHardwareAsset['asset_hardware_id']; ?> &nbsp;</td>
            </tr>
            <tr>
              <th align="left">Owner</th>
              <td><?php echo $row_rsHardwareAsset['user']; ?> &nbsp;</td>
            </tr>
            <tr>
              <th align="left">Training</th>
              <td><?php echo $row_rsHardwareAsset['division']; ?> &nbsp;</td>
            </tr>

            <tr>
              <th colspan="3" align="center"><span style="font-weight: normal">https://www.bloominglabs.org/assets</th>
            </tr>
          </table>
