<?php require_once('Connections/eam.php'); ?>
<?php 
include "phpqrcode/qrlib.php";

if (isset($_GET['size'])) {
  $tagSize = (get_magic_quotes_gpc()) ? $_GET['size'] : addslashes($_GET['size']);
  if ($tagSize == 'S') {
    $tagSize = 'S';
  }
}
if ($tagSize != 'S') {
    $tagSize = 'L';
}
$tag = "Tag$tagSize.php";


if (isset($_GET['recordID'])) {
  if ($tagSize == 'L') {
    QRcode::png('https://www.bloominglabs.org/assets/HardwareDetail.php?recordID='.$_GET['recordID'], false, 'L', 3, 2);
  } else {
    QRcode::png('https://www.bloominglabs.org/assets/HardwareDetail.php?recordID='.$_GET['recordID'], false, 'L', 2, 2);
  }
}

?>
