<?php require_once('Connections/eam.php'); ?>
<?php // Enterprise Asset Management - Graham Fisk - BigSmallweb.com - 2012 // 
$colname_rsHardwareAsset = "-1";
if (isset($_GET['recordID'])) {
  $colname_rsHardwareAsset = (get_magic_quotes_gpc()) ? $_GET['recordID'] : addslashes($_GET['recordID']);
}
mysql_select_db($database_eam, $eam);
$query_rsHardwareAsset = sprintf("SELECT * FROM assets_hardware WHERE asset_hardware_id = %s", $colname_rsHardwareAsset);
$rsHardwareAsset = mysql_query($query_rsHardwareAsset, $eam) or die(mysql_error());
$row_rsHardwareAsset = mysql_fetch_assoc($rsHardwareAsset);
$totalRows_rsHardwareAsset = mysql_num_rows($rsHardwareAsset);
 
$pageTitle="Asset Detail"; ?>
<?php include('includes/header.php'); ?>
    <table border="0" align="center" cellspacing="0" class="tableDetails1" style"margin:0 auto;width 600px;">
      <tr>
        <td style="font-size:100%">
          <fieldset>
          <legend>Asset Detail</legend>
          <table class="tableDetails">
            <tr>
              <th><span style="font-weight: bold">Asset ID</span></th>
              <td><?php echo $row_rsHardwareAsset['asset_hardware_id']; ?></td>
            </tr>
            <tr>
              <th><span style="font-weight: bold">Asset Type</span></th>
              <td><?php echo $row_rsHardwareAsset['asset_type']; ?> &nbsp;</td>
            </tr>
<!--
            <tr>
              <th><span style="font-weight: bold">Monitor Size</span></th>
              <td><?php echo $row_rsHardwareAsset['monitor_size']; ?> &nbsp;</td>
            </tr>
-->
            <tr>
              <th><span style="font-weight: bold">Status</span></th>
              <td><?php echo $row_rsHardwareAsset['status']; ?> &nbsp;</td>
            </tr>
            <tr>
              <th><span style="font-weight: bold">Category</span></th>
              <td><?php echo $row_rsHardwareAsset['platform']; ?> &nbsp;</td>
            </tr>
            <tr>
              <th><span style="font-weight: bold">Make</span></th>
              <td><?php echo $row_rsHardwareAsset['vendor']; ?> &nbsp;</td>
            </tr>
            <tr>
              <th><span style="font-weight: bold">Model</span></th>
              <td><?php echo $row_rsHardwareAsset['model']; ?> &nbsp;</td>
            </tr>
            <tr>
              <th><span style="font-weight: bold">Serial number</span></th>
              <td><?php echo $row_rsHardwareAsset['serialnumber']; ?> &nbsp;</td>
            </tr>
          </table>
          <hr />
          <table class="tableDetails">
            <tr>
              <th>Status</th>
              <td><?php echo $row_rsHardwareAsset['status']; ?> &nbsp;</td>
            </tr>
            <tr>
              <th>Date Inventoried</th>
              <td><?php echo $row_rsHardwareAsset['date_purchase']; ?>&nbsp;</td>
            </tr>
            <tr>
              <th>Warranty Date</th>
              <td><?php echo $row_rsHardwareAsset['warranty']; ?> &nbsp;</td>
            </tr>
            <tr>
              <th>Date Decomissioned</th>
              <td><?php echo $row_rsHardwareAsset['date_decomission']; ?>&nbsp;</td>
            </tr>
          </table>
          <hr />
          <table class="tableDetails">
            <tr>
              <th>Owner</th>
              <td><?php echo $row_rsHardwareAsset['user']; ?> &nbsp;</td>
            </tr>
            <tr>
              <th>User Account </th>
              <td><?php echo $row_rsHardwareAsset['user_account']; ?> &nbsp;</td>
            </tr>
            <tr>
              <th>Training</th>
              <td><?php echo $row_rsHardwareAsset['division']; ?> &nbsp;</td>
            </tr>
            <tr>
              <th>Location</th>
              <td><?php echo $row_rsHardwareAsset['location']; ?> &nbsp;</td>
            </tr>
<!--
            <tr>
              <th>Cube</th>
              <td><?php echo $row_rsHardwareAsset['cube']; ?> &nbsp;</td>
            </tr>
-->
            <tr>
              <th valign="top">Project URL </th>
              <td>
                <a href="<?php echo $row_rsHardwareAsset['field_address']; ?>"><?php echo $row_rsHardwareAsset['field_address']; ?></a>
              </td>
            </tr>
            <tr>
              <th valign="top">Comments</th>
              <td><?php echo $row_rsHardwareAsset['comments']; ?> &nbsp;</td>
            </tr>
          </table>
          </fieldset>
        </td>
        <td valign="top" style="font-size:90%;">
          <p>&nbsp;</p>
          <fieldset style="width:180px;text-align:left;">
          <legend>Manage Record</legend>
<!-- Asset tag print added 1/2/13 / dosman
-->
          <table class="table1">
            <tr>
              <td class="green">
                <form id="upRecord" name="upRecord" method="post" action="HardwareDetailTag.php?recordID=<?php echo $row_rsHardwareAsset['asset_hardware_id']; ?>&size=L">
                  <input type="submit" name="Submit2" value="Generate Asset Tag" />
                </form>
              </td>
            </tr>
          </table>
          <br />
          <table class="table1">
            <tr>
              <td class="green">
                <form id="upRecord" name="upRecord" method="post" action="HardwareDetailTag.php?recordID=<?php echo $row_rsHardwareAsset['asset_hardware_id']; ?>&size=S">
                  <input type="submit" name="Submit2" value="Generate Small Asset Tag" />
                </form>
              </td>
            </tr>
          </table>
          <br />
          <table class="table1">
            <tr>
              <td class="green">
                <form id="upRecord" name="upRecord" method="post" action="HardwareUpdate.php?recordID=<?php echo $row_rsHardwareAsset['asset_hardware_id']; ?>">
                  <input type="submit" name="Submit2" value="Edit This Record" />
                </form>
              </td>
            </tr>
          </table>
          <br />
          <table class="table1">
            <tr>
              <td class="red">
                <form id="delRecord" name="delRecord" method="post" action="HardwareDelete.php?recordID=<?php echo $row_rsHardwareAsset['asset_hardware_id']; ?>">
                  <input name="Submit" type="submit" class="red" value="Delete This Record" />
                </form>
              </td>
            </tr>
          </table>
          </fieldset>
        </td>
      </tr>
    </table>
    <?php include('includes/footer.php'); ?>
<?php
mysql_free_result($rsHardwareAsset);
?>
