<? 
session_start();
session_destroy();
?>
<?php require_once('Connections/eam.php'); ?>
<?php include("includes/header.php"); ?>
  <div style="padding:30px;text-align:center;">
  <h3>You've been logged out!</h3>
  <p><a href="login.php">Log in again?</a></p>
  </div>
<?php include("includes/footer.php"); ?>
