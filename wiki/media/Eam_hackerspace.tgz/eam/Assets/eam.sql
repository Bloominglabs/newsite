-- MySQL dump 10.11
--
-- Host: localhost    Database: eam
-- ------------------------------------------------------
-- Server version	5.0.95

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `assets_hardware`
--

DROP TABLE IF EXISTS `assets_hardware`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `assets_hardware` (
  `asset_hardware_id` int(10) unsigned NOT NULL auto_increment,
  `asset_type` varchar(50) default NULL,
  `vendor` varchar(50) NOT NULL default '',
  `model` varchar(30) NOT NULL default '',
  `serialnumber` varchar(30) default NULL,
  `location` varchar(50) default NULL,
  `date_purchase` varchar(12) default NULL,
  `date_decomission` varchar(12) default NULL,
  `status` varchar(50) default NULL,
  `user` varchar(50) default NULL,
  `division` varchar(50) default NULL,
  `platform` varchar(50) default NULL,
  `comments` text,
  `monitor_size` int(2) default NULL,
  `warranty` varchar(15) default NULL,
  `cube` varchar(10) default NULL,
  `field_address` text,
  `user_account` varchar(12) default NULL,
  PRIMARY KEY  (`asset_hardware_id`)
) ENGINE=MyISAM AUTO_INCREMENT=217 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `assets_hardware`
--

LOCK TABLES `assets_hardware` WRITE;
/*!40000 ALTER TABLE `assets_hardware` DISABLE KEYS */;
/*!40000 ALTER TABLE `assets_hardware` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `assets_hardware_monitor_size`
--

CREATE TABLE IF NOT EXISTS `assets_hardware_monitor_size` (
  `size` int(2) NOT NULL default '0',
  `id` int(11) NOT NULL auto_increment,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=12 ;

--
-- Dumping data for table `assets_hardware_monitor_size`
--

--
-- Table structure for table `assets_hardware_platform`
--

DROP TABLE IF EXISTS `assets_hardware_platform`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `assets_hardware_platform` (
  `platform_id` int(10) unsigned NOT NULL auto_increment,
  `platform` varchar(100) NOT NULL default '',
  `comments` text,
  PRIMARY KEY  (`platform_id`)
) ENGINE=MyISAM AUTO_INCREMENT=30 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `assets_hardware_platform`
--

LOCK TABLES `assets_hardware_platform` WRITE;
/*!40000 ALTER TABLE `assets_hardware_platform` DISABLE KEYS */;
INSERT INTO `assets_hardware_platform` VALUES (1,'PC\'s & Servers','Computer hardware'),(2,'Mac','Apple Macintosh Hardware'),(8,'Printer','Printers, Multifunction Devices'),(9,'Mobile','Phones and Tablets'),(12,'Furniture','Tables, chairs, fans, etc.'),(13,'Power Tool','Electrical hand or bench operated tools'),(14,'Rapid Prototyping','Laser cutters, 3D printers, CNC, etc.'),(15,'PCB assembly','Anything used for soldering and/or mass PCB assembly'),(16,'Arts & Crafts',NULL),(17,'Textiles',NULL),(20,'Oxy-Acetylene','Torch'),(19,'Welder',NULL),(21,'Storage','Any kind of physical storage. Shelves, server racks, boxes, etc.'),(22,'Kitchen Equipment',NULL),(23,'Electronic Test Equipment',NULL),(24,'Safety Equipment',NULL),(25,'Office Equipment','Vacuums, fans - not furniture'),(26,'Repurposed','For items which were intended for one purpose (say, a vacuum cleaner) which now is used for another (vacuum forming table).'),(27,'Network Gear',NULL),(28,'Other tool','Any tool that doesn\'t fit anywhere else'),(29,'Audio Visual','AV gear, game consoles, projectors, speakers, etc.');
/*!40000 ALTER TABLE `assets_hardware_platform` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `assets_hardware_status`
--

DROP TABLE IF EXISTS `assets_hardware_status`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `assets_hardware_status` (
  `assets_hardware_status` varchar(50) NOT NULL default '',
  `id` int(11) NOT NULL auto_increment,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `assets_hardware_status`
--

LOCK TABLES `assets_hardware_status` WRITE;
/*!40000 ALTER TABLE `assets_hardware_status` DISABLE KEYS */;
INSERT INTO `assets_hardware_status` VALUES ('Deployed',2),('Inventory',3),('Retired',4),('Off-site',5),('Broken',6),('Pre-deployment',7);
/*!40000 ALTER TABLE `assets_hardware_status` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `assets_hardware_type`
--

DROP TABLE IF EXISTS `assets_hardware_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `assets_hardware_type` (
  `assets_hardware_type` varchar(15) NOT NULL default '',
  `id` int(11) NOT NULL auto_increment,
  `comments` text,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=114 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `assets_hardware_type`
--

LOCK TABLES `assets_hardware_type` WRITE;
/*!40000 ALTER TABLE `assets_hardware_type` DISABLE KEYS */;
INSERT INTO `assets_hardware_type` VALUES ('Laptop',1,'Portable Computer'),('Desktop',2,'Desktop computer'),('Monitor',3,'LCD or CRT Monitor'),('Printer',4,'Network and personal printers'),('Peripheral',5,'Any Peripheral'),('Other',6,'Any hardware item which doesn\'t fit a defined category'),('Server',7,'Servers'),('Drill Press',17,NULL),('Smartphone',9,'SmartPhone\r\n'),('Electric Drill',16,'(not battery operated)'),('Cordless Drill',15,NULL),('Lathe',18,NULL),('Filing cabinet',19,NULL),('White board',20,NULL),('Chair',21,NULL),('Bench grinder',22,NULL),('Reflow oven',23,'PCB soldering reflow oven'),('KnittingMachine',25,NULL),('Mill',26,'milling machines'),('Table',27,NULL),('Workbench',28,NULL),('Soldering Iron',29,NULL),('Oscilloscope',30,NULL),('Stereo',31,NULL),('Speaker cabinet',32,NULL),('Table Saw',33,NULL),('Chop saw',34,'wood'),('Bench sander',35,NULL),('Sander',36,NULL),('Bandsaw',37,NULL),('TIG Welder',38,NULL),('MIG Welder',39,NULL),('Arc Welder',40,NULL),('Torch',43,'Metal working'),('Propane Torch',42,'Metal working, copper sweat, etc.'),('Shelving unit',44,NULL),('Server Rack',45,NULL),('Locker',46,'Multi-locker storage'),('Jigsaw',47,NULL),('Air Compressor',48,NULL),('Microwave Oven',49,NULL),('Refrigerator',50,NULL),('Router table',51,NULL),('Router',52,NULL),('Angle Grinder',53,NULL),('ShopVac',54,NULL),('Desk',55,NULL),('Cabinet',56,'Storage'),('Storage Bin',57,'Small parts storage'),('Storage tote',58,'Portable small parts container'),('Power strip',59,'AC, 115V'),('Network switch',60,'Ethernet, etc.'),('Computer',61,'PC, Mac, etc.'),('Square',62,'Credit card processing adapter for smartphones'),('Projector',63,'Overhead projector'),('Book shelf',64,NULL),('Rolling Cart',65,NULL),('RFID system',66,'RFID controller and accessories (readers, PIR sensors, power supply, etc.)'),('Fire Extinguish',67,NULL),('Supply Box',68,'Multi-container parts bins'),('Telescope',69,NULL),('Vacuum cleaner',70,NULL),('Coat Rack',71,NULL),('Sign',72,NULL),('Power Supply',73,'Bench power supplies, wall-warts, anything we use on a regular basis'),('UPS',74,'Uninterruptible Power Supply'),('PaperTowelDisp',75,'Restroom equipment'),('TV',76,'television'),('Power Wheels',92,'The kids toy'),('Tool box',78,NULL),('Ladder',79,NULL),('Home made',80,'Custom tools'),('Fan',81,'Box fans, etc.'),('Wireless router',82,NULL),('IP Router',83,'Network gear'),('Vise',84,NULL),('Clamp',85,'Wood/tool clamps'),('Utility sink',86,NULL),('Leaf Blower',87,NULL),('Drill bit caddy',88,NULL),('Audio Receiver',89,NULL),('PS/2 Console',90,'Game console'),('Karaoke Machine',91,NULL),('Vacuum Table',93,'For plastic vacuum forming'),('Donation Box',94,NULL),('Couch',95,'Furniture '),('Heat gun',96,NULL),('Socket/Tool set',97,NULL),('Hole saw',98,'Single tools, kits, etc.'),('Digital Caliper',99,NULL),('Clothing Iron',100,NULL),('Lamp',101,NULL),('Transformer',102,'Variable, static, etc.'),('Roomba',104,'vacuum cleaner robots!'),('Multimeter',105,NULL),('MIG Welder',106,'Wire feed'),('Sewing Machine',107,NULL),('WheelChair',108,'Electric wheel chair'),('CNC chassis',109,'X Y Z stepper'),('Mop bucket',110,NULL),('Frequency Count',111,NULL),('First Aid Kit',112,NULL),('iMac',113,NULL);
/*!40000 ALTER TABLE `assets_hardware_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `assets_software`
--

DROP TABLE IF EXISTS `assets_software`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `assets_software` (
  `asset_software_id` int(10) unsigned NOT NULL auto_increment,
  `asset` varchar(100) NOT NULL default '',
  `vendor` varchar(30) NOT NULL default '',
  `version` varchar(20) NOT NULL,
  `date_purchase` varchar(12) default NULL,
  `license_type` varchar(50) NOT NULL default '',
  `status` varchar(50) default NULL,
  `user` varchar(50) default NULL,
  `division` varchar(50) default NULL,
  `comments` text,
  `platform` varchar(15) default NULL,
  `location` varchar(30) default NULL,
  `seats` varchar(12) default NULL,
  PRIMARY KEY  (`asset_software_id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `assets_software`
--

--
-- Table structure for table `assets_software_license`
--

--
-- Dumping data for table `assets_software_license`
--

--
-- Table structure for table `assets_software_platform`
--

--
-- Dumping data for table `assets_software_platform`
--

--
-- Table structure for table `company`
--

DROP TABLE IF EXISTS `company`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `company` (
  `company_id` int(11) NOT NULL auto_increment,
  `company_name` varchar(200) NOT NULL,
  PRIMARY KEY  (`company_id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `company`
--

LOCK TABLES `company` WRITE;
/*!40000 ALTER TABLE `company` DISABLE KEYS */;
INSERT INTO `company` VALUES (1,'Hackerspace Incorporated');
/*!40000 ALTER TABLE `company` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `division`
--

DROP TABLE IF EXISTS `division`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `division` (
  `division` varchar(15) NOT NULL default '',
  `id` int(11) NOT NULL auto_increment,
  `comments` text,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `division`
--

LOCK TABLES `division` WRITE;
/*!40000 ALTER TABLE `division` DISABLE KEYS */;
INSERT INTO `division` VALUES ('Not required',7,'Training not required to operate'),('Required',3,'Training is required on this tool before operating');
/*!40000 ALTER TABLE `division` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `location`
--

DROP TABLE IF EXISTS `location`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `location` (
  `location` varchar(50) NOT NULL default '',
  `id` int(11) NOT NULL auto_increment,
  `comments` text,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=19 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `location`
--

LOCK TABLES `location` WRITE;
/*!40000 ALTER TABLE `location` DISABLE KEYS */;
INSERT INTO `location` VALUES ('N/A',16,'No location specified'),('Workshop',13,'Main workshop room'),('Front room',17,'Main entrance room'),('Restroom',18,NULL);
/*!40000 ALTER TABLE `location` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `members`
--

DROP TABLE IF EXISTS `members`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `members` (
  `id` int(11) unsigned NOT NULL auto_increment,
  `username` varchar(30) default NULL,
  `password` varchar(30) NOT NULL default '',
  `firstname` varchar(100) NOT NULL,
  `lastname` varchar(100) NOT NULL,
  `role` varchar(24) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `members`
--

LOCK TABLES `members` WRITE;
/*!40000 ALTER TABLE `members` DISABLE KEYS */;
INSERT INTO `members` VALUES (1,'admin','eam123','Primary','Admin','admin'),(2,'dude','dude','Member','Hacker','admin');
/*!40000 ALTER TABLE `members` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `vendors`
--

DROP TABLE IF EXISTS `vendors`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `vendors` (
  `vendor_id` int(10) unsigned NOT NULL auto_increment,
  `vendor` varchar(100) NOT NULL default '',
  `comments` text,
  PRIMARY KEY  (`vendor_id`)
) ENGINE=MyISAM AUTO_INCREMENT=74 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `vendors`
--

LOCK TABLES `vendors` WRITE;
/*!40000 ALTER TABLE `vendors` DISABLE KEYS */;
INSERT INTO `vendors` VALUES (1,'Dell','Dell desktops, laptops, and accessories'),(2,'Lenovo','Laptops and accessories'),(3,'HP','HP printers and accessories'),(4,'IBM','IBM laptops and accessories'),(5,'Apple','Apple products'),(7,'Asus','Asus - the greek god of Netbooks'),(9,'Brother','Printers'),(13,'Makita','power tools'),(14,'Atlas','vintage lathes, mills, and power tools'),(15,'Delta','shop tools'),(16,'Central Pneumatic','air tools'),(17,'Other','Unknown or unlisted vendor'),(18,'Milwaukee','power tools'),(19,'Weller',NULL),(20,'BK Precision','scopes and meters'),(21,'Technitronic',NULL),(22,'Epilog','laser'),(23,'Sears',NULL),(24,'Juki','Japanese company/knitting machines, pick-n-place, etc.'),(25,'Full Spectrum','laser'),(26,'RCA','Stereos, tv\'s, etc.'),(27,'GE','General Electric'),(28,'Performax','Drill presses, power tools'),(29,'Jet','Machine and wood tools'),(30,'Pogo','Pogo Linux server'),(31,'Eastwood','Welding equipment'),(32,'Craftsman',NULL),(33,'Whirlpool',NULL),(34,'Tool Shop',NULL),(35,'Wolfcraft','Router tables and such'),(36,'Westinghouse',NULL),(37,'ShopVac',NULL),(38,'Torch','Reflow ovens, etc.'),(39,'Hitachi',NULL),(40,'Kenwood',NULL),(41,'Black + Decker',NULL),(42,'Galaxy','Household appliances'),(43,'Gorilla Racks','Shelving, workbenches'),(44,'Harber','Cleaning & utility products, mop buckets, etc.'),(45,'Home made','Constructed equipment'),(46,'Masterforce','tool brand'),(47,'Cisco','network gear'),(48,'iRobot','Roomba\'s and other robots'),(49,'Electrolux','vacuum cleaners'),(50,'Honeywell','Household appliances to aircraft & military equipment'),(51,'Weed Eater','Yard equipment'),(52,'Heath Kit','Electronics kits'),(53,'Chapman Power Supply','Electronic equipment'),(54,'Radio Shack',NULL),(55,'Sony',NULL),(56,'The Superior Electric Co.','Variable transformers, power equipment, etc.'),(57,'Hoover','Vacuum cleaners, etc.'),(58,'Dirt Devil','Vacuum cleaners, etc.'),(59,'Gateway','PC\'s, monitors, etc.'),(60,'Linksys','Network gear'),(61,'Holmes','Household appliances, box fans, etc.'),(62,'Clarke','Welders, tools'),(63,'Pioneer','Audio equipment'),(64,'Curtis','AV gear'),(65,'Goldstar','Electronic equipment, AV, etc.'),(66,'Fisher Price','Kids toys, power wheels, etc.'),(67,'Golden','Power wheel chairs'),(68,'Porter Cable','Power tools'),(69,'Eureka','Household appliances, vacuum cleaners, etc.'),(70,'Rubbermaid',NULL),(71,'Euro-pro','household appliances, clothing irons, etc.'),(72,'Infocus','projectors, office equipment'),(73,'Balance Technologies','Cheap laptops');
/*!40000 ALTER TABLE `vendors` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `vendors_software`
--

--
-- Dumping data for table `vendors_software`
--

-- Dump completed on 2013-01-21 12:08:59
