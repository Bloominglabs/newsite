<?php require_once('Connections/eam.php'); ?>
<?php // Enterprise Asset Management - Graham Fisk - BigSmallweb.com - 2012 // 
$colname_rsHardwareAsset = "-1";
if (isset($_GET['recordID'])) {
  $colname_rsHardwareAsset = (get_magic_quotes_gpc()) ? $_GET['recordID'] : addslashes($_GET['recordID']);
}

if (isset($_GET['size'])) {
  $tagSize = (get_magic_quotes_gpc()) ? $_GET['size'] : addslashes($_GET['size']);
  if ($tagSize == 'S') {
    $tagSize = 'S';
  } 
}
if ($tagSize != 'S') {
    $tagSize = 'L';
}

mysql_select_db($database_eam, $eam);
$query_rsHardwareAsset = sprintf("SELECT * FROM assets_hardware WHERE asset_hardware_id = %s", $colname_rsHardwareAsset);
$rsHardwareAsset = mysql_query($query_rsHardwareAsset, $eam) or die(mysql_error());
$row_rsHardwareAsset = mysql_fetch_assoc($rsHardwareAsset);
$totalRows_rsHardwareAsset = mysql_num_rows($rsHardwareAsset);
 
$pageTitle="Asset Tag";
$tag = "Tag$tagSize.php";
include("$tag"); ?>

          </fieldset>
        </td>
        <td valign="top" style="font-size:90%;">
          <p>&nbsp;</p>
        </td>
      </tr>
    </table>
    <?php /*include('includes/footer.php'); */ ?>
<?php
mysql_free_result($rsHardwareAsset);
?>
