<?php
$host = 'localhost'; // MYSQL database host adress
$db = 'eam_bloominglabs'; // MYSQL database name
$user = 'eam_bloominglabs'; // Mysql Datbase user
$pass = 'c0rkDO4k23zx'; // Mysql Datbase password
 
// Connect to the database
$link = mysql_connect($host, $user, $pass); mysql_select_db($db);
?>
