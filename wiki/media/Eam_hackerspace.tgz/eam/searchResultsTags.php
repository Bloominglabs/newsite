<?php require_once('Connections/eam.php'); ?>
<?php // Enterprise Asset Management - Graham Fisk - BigSmallweb.com - 2012 // 
$maxRows_rsHardwareAssets = 10000;
$pageNum_rsHardwareAssets = 0;
if (isset($_GET['pageNum_rsHardwareAssets'])) {
  $pageNum_rsHardwareAssets = $_GET['pageNum_rsHardwareAssets'];
}
$startRow_rsHardwareAssets = $pageNum_rsHardwareAssets * $maxRows_rsHardwareAssets;

/* 1/4/13 - dosman - added assetid, division (training), status search */
$varAssetid_rsHardwareAssets = "-1";
if (isset($_POST['asset_hardware_id'])) {
  $varAssetid_rsHardwareAssets = (get_magic_quotes_gpc()) ? $_POST['asset_hardware_id'] : addslashes($_POST['asset_hardware_id']);
}

$varDivision_rsHardwareAssets = "-1";
if (isset($_POST['division'])) {
  $varDivision_rsHardwareAssets = (get_magic_quotes_gpc()) ? $_POST['division'] : addslashes($_POST['division']);
}

$varStatus_rsHardwareAssets = "-1";
if (isset($_POST['status'])) {
  $varStatus_rsHardwareAssets = (get_magic_quotes_gpc()) ? $_POST['status'] : addslashes($_POST['status']);
}

$varPDate_rsHardwareAssets = "-1";
if (isset($_POST['date_purchase'])) {
  $varPDate_rsHardwareAssets = (get_magic_quotes_gpc()) ? $_POST['date_purchase'] : addslashes($_POST['date_purchase']);
}
/* end of mods */

$varModel_rsHardwareAssets = "-1";
if (isset($_POST['model'])) {
  $varModel_rsHardwareAssets = (get_magic_quotes_gpc()) ? $_POST['model'] : addslashes($_POST['model']);
}
$varUser_rsHardwareAssets = "-1";
if (isset($_POST['user'])) {
  $varUser_rsHardwareAssets = (get_magic_quotes_gpc()) ? $_POST['user'] : addslashes($_POST['user']);
}
$varUserAccount_rsHardwareAssets = "-1";
if (isset($_POST['user_account'])) {
  $varUserAccount_rsHardwareAssets = (get_magic_quotes_gpc()) ? $_POST['user_account'] : addslashes($_POST['user_account']);
}
$varLocation_rsHardwareAssets = "-1";
if (isset($_POST['location'])) {
  $varLocation_rsHardwareAssets = (get_magic_quotes_gpc()) ? $_POST['location'] : addslashes($_POST['location']);
}
$varSerialnumber_rsHardwareAssets = "-1";
if (isset($_POST['serialnumber'])) {
  $varSerialnumber_rsHardwareAssets = (get_magic_quotes_gpc()) ? $_POST['serialnumber'] : addslashes($_POST['serialnumber']);
}
$varAssettype_rsHardwareAssets = "-1";
if (isset($_POST['asset_type'])) {
  $varAssettype_rsHardwareAssets = (get_magic_quotes_gpc()) ? $_POST['asset_type'] : addslashes($_POST['asset_type']);
}
$varVendor_rsHardwareAssets = "-1";
if (isset($_POST['vendor'])) {
  $varVendor_rsHardwareAssets = (get_magic_quotes_gpc()) ? $_POST['vendor'] : addslashes($_POST['vendor']);
}
$varPlatform_rsHardwareAssets = "-1";
if (isset($_POST['platform'])) {
  $varPlatform_rsHardwareAssets = (get_magic_quotes_gpc()) ? $_POST['platform'] : addslashes($_POST['platform']);
}

$tagSize = "-1";
if (isset($_POST['size'])) {
  $tagSize = (get_magic_quotes_gpc()) ? $_POST['size'] : addslashes($_POST['size']);
  if ($tagSize == 'S') {
    $tagSize = 'S';
  }
}
if ($tagSize != 'S') {
    $tagSize = 'L';
}
$tag = "Tag$tagSize.php";

mysql_select_db($database_eam, $eam);

$query_rsHardwareAssets = sprintf("SELECT * FROM assets_hardware WHERE date_purchase = '%s' or status = '%s' or division = '%s' or asset_hardware_id = '%s' or vendor = '%s' or platform = '%s' or asset_type = '%s' or serialnumber = '%s' or user = '%s' or user_account = '%s' or location = '%s' or model = '%s' ORDER BY assets_hardware.`user`", $varPDate_rsHardwareAssets,$varStatus_rsHardwareAssets,$varDivision_rsHardwareAssets,$varAssetid_rsHardwareAssets,$varVendor_rsHardwareAssets,$varPlatform_rsHardwareAssets,$varAssettype_rsHardwareAssets,$varSerialnumber_rsHardwareAssets,$varUser_rsHardwareAssets,$varUserAccount_rsHardwareAssets,$varLocation_rsHardwareAssets,$varModel_rsHardwareAssets);

$query_limit_rsHardwareAssets = sprintf("%s LIMIT %d, %d", $query_rsHardwareAssets, $startRow_rsHardwareAssets, $maxRows_rsHardwareAssets);
$rsHardwareAssets = mysql_query($query_limit_rsHardwareAssets, $eam) or die(mysql_error());
//$row_rsHardwareAssets = mysql_fetch_assoc($rsHardwareAssets);
$row_rsHardwareAsset = mysql_fetch_assoc($rsHardwareAssets);

if (isset($_GET['totalRows_rsHardwareAssets'])) {
  $totalRows_rsHardwareAssets = $_GET['totalRows_rsHardwareAssets'];
} else {
  $all_rsHardwareAssets = mysql_query($query_rsHardwareAssets);
  $totalRows_rsHardwareAssets = mysql_num_rows($all_rsHardwareAssets);
}
$totalPages_rsHardwareAssets = ceil($totalRows_rsHardwareAssets/$maxRows_rsHardwareAssets)-1;

$queryString_rsHardwareAssets = "";
if (!empty($_SERVER['QUERY_STRING'])) {
  $params = explode("&", $_SERVER['QUERY_STRING']);
  $newParams = array();
  foreach ($params as $param) {
    if (stristr($param, "pageNum_rsHardwareAssets") == false && 
        stristr($param, "totalRows_rsHardwareAssets") == false) {
      array_push($newParams, $param);
    }
  }
  if (count($newParams) != 0) {
    $queryString_rsHardwareAssets = "&" . htmlentities(implode("&", $newParams));
  }
}
$queryString_rsHardwareAssets = sprintf("&totalRows_rsHardwareAssets=%d%s", $totalRows_rsHardwareAssets, $queryString_rsHardwareAssets);
 
$pageTitle="Search"; ?>

<?php
$currentPage = $_SERVER["PHP_SELF"];
?>

<?php $pageTitle="Asset Tag List"; ?>
    <table class="table1">
      <tr>
      </tr>
      <?php do { ?>

      <?php include("$tag"); ?>

          </fieldset>
         </td>
        <td valign="top" style="font-size:90%;">
          <p>&nbsp;</p>
        </td>
      </tr>

      <?php } while ($row_rsHardwareAsset = mysql_fetch_assoc($rsHardwareAssets)); ?>
    </table>
</table>

<?php
mysql_free_result($rsHardwareAssets);
?>
