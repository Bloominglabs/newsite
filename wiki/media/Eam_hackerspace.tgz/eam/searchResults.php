<?php require_once('Connections/eam.php'); ?>
<?php // Enterprise Asset Management - Graham Fisk - BigSmallweb.com - 2012 // 
$maxRows_rsHardwareAssets = 50;
$pageNum_rsHardwareAssets = 0;
if (isset($_GET['pageNum_rsHardwareAssets'])) {
  $pageNum_rsHardwareAssets = $_GET['pageNum_rsHardwareAssets'];
}
$startRow_rsHardwareAssets = $pageNum_rsHardwareAssets * $maxRows_rsHardwareAssets;

/* 1/4/13 - dosman - added assetid, division (training), status search */
$varAssetid_rsHardwareAssets = "-1";
if (isset($_POST['asset_hardware_id'])) {
  $varAssetid_rsHardwareAssets = (get_magic_quotes_gpc()) ? $_POST['asset_hardware_id'] : addslashes($_POST['asset_hardware_id']);
}

$varDivision_rsHardwareAssets = "-1";
if (isset($_POST['division'])) {
  $varDivision_rsHardwareAssets = (get_magic_quotes_gpc()) ? $_POST['division'] : addslashes($_POST['division']);
}

$varStatus_rsHardwareAssets = "-1";
if (isset($_POST['status'])) {
  $varStatus_rsHardwareAssets = (get_magic_quotes_gpc()) ? $_POST['status'] : addslashes($_POST['status']);
}

$varPDate_rsHardwareAssets = "-1";
if (isset($_POST['date_purchase'])) {
  $varPDate_rsHardwareAssets = (get_magic_quotes_gpc()) ? $_POST['date_purchase'] : addslashes($_POST['date_purchase']);
}
/* end of mods */

$varModel_rsHardwareAssets = "-1";
if (isset($_POST['model'])) {
  $varModel_rsHardwareAssets = (get_magic_quotes_gpc()) ? $_POST['model'] : addslashes($_POST['model']);
}
$varUser_rsHardwareAssets = "-1";
if (isset($_POST['user'])) {
  $varUser_rsHardwareAssets = (get_magic_quotes_gpc()) ? $_POST['user'] : addslashes($_POST['user']);
}
$varUserAccount_rsHardwareAssets = "-1";
if (isset($_POST['user_account'])) {
  $varUserAccount_rsHardwareAssets = (get_magic_quotes_gpc()) ? $_POST['user_account'] : addslashes($_POST['user_account']);
}
$varLocation_rsHardwareAssets = "-1";
if (isset($_POST['location'])) {
  $varLocation_rsHardwareAssets = (get_magic_quotes_gpc()) ? $_POST['location'] : addslashes($_POST['location']);
}
$varSerialnumber_rsHardwareAssets = "-1";
if (isset($_POST['serialnumber'])) {
  $varSerialnumber_rsHardwareAssets = (get_magic_quotes_gpc()) ? $_POST['serialnumber'] : addslashes($_POST['serialnumber']);
}
$varAssettype_rsHardwareAssets = "-1";
if (isset($_POST['asset_type'])) {
  $varAssettype_rsHardwareAssets = (get_magic_quotes_gpc()) ? $_POST['asset_type'] : addslashes($_POST['asset_type']);
}
$varVendor_rsHardwareAssets = "-1";
if (isset($_POST['vendor'])) {
  $varVendor_rsHardwareAssets = (get_magic_quotes_gpc()) ? $_POST['vendor'] : addslashes($_POST['vendor']);
}
$varPlatform_rsHardwareAssets = "-1";
if (isset($_POST['platform'])) {
  $varPlatform_rsHardwareAssets = (get_magic_quotes_gpc()) ? $_POST['platform'] : addslashes($_POST['platform']);
}
mysql_select_db($database_eam, $eam);

$query_rsHardwareAssets = sprintf("SELECT * FROM assets_hardware WHERE date_purchase = '%s' or status = '%s' or division = '%s' or asset_hardware_id = '%s' or vendor = '%s' or platform = '%s' or asset_type = '%s' or serialnumber = '%s' or user = '%s' or user_account = '%s' or location = '%s' or model = '%s' ORDER BY assets_hardware.`user`", $varPDate_rsHardwareAssets,$varStatus_rsHardwareAssets,$varDivision_rsHardwareAssets,$varAssetid_rsHardwareAssets,$varVendor_rsHardwareAssets,$varPlatform_rsHardwareAssets,$varAssettype_rsHardwareAssets,$varSerialnumber_rsHardwareAssets,$varUser_rsHardwareAssets,$varUserAccount_rsHardwareAssets,$varLocation_rsHardwareAssets,$varModel_rsHardwareAssets);

$query_limit_rsHardwareAssets = sprintf("%s LIMIT %d, %d", $query_rsHardwareAssets, $startRow_rsHardwareAssets, $maxRows_rsHardwareAssets);
$rsHardwareAssets = mysql_query($query_limit_rsHardwareAssets, $eam) or die(mysql_error());
$row_rsHardwareAssets = mysql_fetch_assoc($rsHardwareAssets);

if (isset($_GET['totalRows_rsHardwareAssets'])) {
  $totalRows_rsHardwareAssets = $_GET['totalRows_rsHardwareAssets'];
} else {
  $all_rsHardwareAssets = mysql_query($query_rsHardwareAssets);
  $totalRows_rsHardwareAssets = mysql_num_rows($all_rsHardwareAssets);
}
$totalPages_rsHardwareAssets = ceil($totalRows_rsHardwareAssets/$maxRows_rsHardwareAssets)-1;

$queryString_rsHardwareAssets = "";
if (!empty($_SERVER['QUERY_STRING'])) {
  $params = explode("&", $_SERVER['QUERY_STRING']);
  $newParams = array();
  foreach ($params as $param) {
    if (stristr($param, "pageNum_rsHardwareAssets") == false && 
        stristr($param, "totalRows_rsHardwareAssets") == false) {
      array_push($newParams, $param);
    }
  }
  if (count($newParams) != 0) {
    $queryString_rsHardwareAssets = "&" . htmlentities(implode("&", $newParams));
  }
}
$queryString_rsHardwareAssets = sprintf("&totalRows_rsHardwareAssets=%d%s", $totalRows_rsHardwareAssets, $queryString_rsHardwareAssets);
 
$pageTitle="Search"; ?>
<?php include('includes/header.php'); ?>
<?php
$currentPage = $_SERVER["PHP_SELF"];
?>
<h3>Search Assets </h3>

<form id="searchAssets" name="searchAssets" method="post" action="searchResultsTags.php">
<input type="hidden" name="asset_hardware_id" value="<?php echo $varAssetid_rsHardwareAssets; ?>" />
<input type="hidden" name="serialnumber" value="<?php echo $varSerialnumber_rsHardwareAssets; ?>" />
<input type="hidden" name="vendor" value="<?php echo $varVendor_rsHardwareAssets; ?>" />
<input type="hidden" name="model" value="<?php echo $varModel_rsHardwareAssets; ?>" />
<input type="hidden" name="platform" value="<?php echo $varPlatform_rsHardwareAssets; ?>" />
<input type="hidden" name="asset_type" value="<?php echo $varAssettype_rsHardwareAssets; ?>" />
<input type="hidden" name="division" value="<?php echo $varDivision_rsHardwareAssets; ?>" />
<input type="hidden" name="status" value="<?php echo $varStatus_rsHardwareAssets; ?>" />
<input type="hidden" name="date_purchase" value="<?php echo $varPDate_rsHardwareAssets; ?>" />
<input type="hidden" name="user" value="<?php echo $varUser_rsHardwareAssets; ?>" />
<input type="hidden" name="location" value="<?php echo $varLocation_rsHardwareAssets; ?>" />
<input type="hidden" name="size" value="L">
<input type="submit" name="Submit" value="Generate Full Size Asset Tags From Results" />
</form>
<form id="searchAssets" name="searchAssets" method="post" action="searchResultsTags.php">
<input type="hidden" name="asset_hardware_id" value="<?php echo $varAssetid_rsHardwareAssets; ?>" />
<input type="hidden" name="serialnumber" value="<?php echo $varSerialnumber_rsHardwareAssets; ?>" />
<input type="hidden" name="vendor" value="<?php echo $varVendor_rsHardwareAssets; ?>" />
<input type="hidden" name="model" value="<?php echo $varModel_rsHardwareAssets; ?>" />
<input type="hidden" name="platform" value="<?php echo $varPlatform_rsHardwareAssets; ?>" />
<input type="hidden" name="asset_type" value="<?php echo $varAssettype_rsHardwareAssets; ?>" />
<input type="hidden" name="division" value="<?php echo $varDivision_rsHardwareAssets; ?>" />
<input type="hidden" name="status" value="<?php echo $varStatus_rsHardwareAssets; ?>" />
<input type="hidden" name="date_purchase" value="<?php echo $varPDate_rsHardwareAssets; ?>" />
<input type="hidden" name="user" value="<?php echo $varUser_rsHardwareAssets; ?>" />
<input type="hidden" name="location" value="<?php echo $varLocation_rsHardwareAssets; ?>" />
<input type="hidden" name="size" value="S">
<input type="submit" name="Submit" value="Generate Small Size Asset Tags From Results" />
</form>

<table class="table1">
  <tr>
    <th>Asset Type </th>
    <th>Vendor</th>
    <th>Model</th>
    <th>Serial Number</th>
    <th>Category </th>	
    <th>Training </th>	
    <th>Location</th>
    <th>Status</th>	
    <th>Owner</th>
    <th>Location</th>
<!--    <th>User Account</th>	
-->
    <th>View </th>
    <th>Edit</th>
  </tr>
  <?php do { ?>
    <tr onmouseover="this.bgColor='#F2F7FF'" onmouseout="this.bgColor='#FFFFFF'";>
      <td><?php echo $row_rsHardwareAssets['asset_type']; ?></td>
      <td><?php echo $row_rsHardwareAssets['vendor']; ?></td>	
      <td><?php echo $row_rsHardwareAssets['model']; ?></td>
      <td><?php echo $row_rsHardwareAssets['serialnumber']; ?></td>
      <td><?php echo $row_rsHardwareAssets['platform']; ?></td>
      <td><?php echo $row_rsHardwareAssets['division']; ?></td>
      <td><?php echo $row_rsHardwareAssets['location']; ?></td>
	  <td><?php echo $row_rsHardwareAssets['status']; ?></td>	  
      <td><?php echo $row_rsHardwareAssets['user']; ?></td>
      <td><?php echo $row_rsHardwareAssets['location']; ?></td>
<!--
      <td><?php echo $row_rsHardwareAssets['user_account']; ?></td>
-->
      <td><a href="HardwareDetail.php?recordID=<?php echo $row_rsHardwareAssets['asset_hardware_id']; ?>">View</a></td>
      <td><a href="HardwareUpdate.php?recordID=<?php echo $row_rsHardwareAssets['asset_hardware_id']; ?>">Edit</a></td>
    </tr>
    <?php } while ($row_rsHardwareAssets = mysql_fetch_assoc($rsHardwareAssets)); ?>
</table>
<table class="pagination">
<tr>
  <td><div style="float:left;">Records <?php echo ($startRow_rsHardwareAssets + 1) ?> to <?php echo min($startRow_rsHardwareAssets + $maxRows_rsHardwareAssets, $totalRows_rsHardwareAssets) ?> of <?php echo $totalRows_rsHardwareAssets ?></div>
  <div style="float:right;">
    <table class="pagination1">
      <tr>
        <?php if ($pageNum_rsHardwareAssets > 0) { // Show if not first page ?>
          <td> <a href="<?php printf("%s?pageNum_rsHardwareAssets=%d%s", $currentPage, 0, $queryString_rsHardwareAssets); ?>"><img src="images/First.gif" alt="First Page" title="First Page" /></a> </td>
            <?php } // Show if not first page ?>
			
        <?php if ($pageNum_rsHardwareAssets > 0) { // Show if not first page ?>	
          <td> <a href="<?php printf("%s?pageNum_rsHardwareAssets=%d%s", $currentPage, max(0, $pageNum_rsHardwareAssets - 1), $queryString_rsHardwareAssets); ?>"><img src="images/Previous.gif" alt="Previous Page" title="Previous Page" /></a> </td>
         <?php } // Show if not first page ?>
		 
        <?php if ($pageNum_rsHardwareAssets < $totalPages_rsHardwareAssets) { // Show if not last page ?>
          <td> <a href="<?php printf("%s?pageNum_rsHardwareAssets=%d%s", $currentPage, min($totalPages_rsHardwareAssets, $pageNum_rsHardwareAssets + 1), $queryString_rsHardwareAssets); ?>"><img src="images/Next.gif" alt="Next Page" title="Next Page" /></a> </td>
            <?php } // Show if not last page ?>
        <?php if ($pageNum_rsHardwareAssets < $totalPages_rsHardwareAssets) { // Show if not last page ?>
          <td> <a href="<?php printf("%s?pageNum_rsHardwareAssets=%d%s", $currentPage, $totalPages_rsHardwareAssets, $queryString_rsHardwareAssets); ?>"><img src="images/Last.gif" alt="Last Page" title="Last Page" /></a> </td>
            <?php } // Show if not last page ?>
        </tr>
    </table>
	</div>
  </td>
  </tr>
</table>	
  <?php include('includes/footer.php'); ?>
<?php
mysql_free_result($rsHardwareAssets);
?>
